# ============================================================================
# DIGIvloot overview — observation frequency by vessel, device, and week
#
# Scans all Parquet files under <ONEDRIVE_POSEIDAT>/raw/ and /processed/,
# builds a summary tibble, and offers both a heatmap plot and a gt table.
#
# Dependencies: arrow, dplyr, tidyr, lubridate, ggplot2, scales, gt
# Source this file or copy the functions into your DIGIvloot overview.R
# ============================================================================

library(arrow)
library(dplyr)
library(tidyr)
library(lubridate)
library(ggplot2)
library(scales)
library(gt)  # produce nice tables

# Null-coalescing operator (available in R 4.4+ as base::`%||%`; defined here for compatibility)
`%||%` <- function(x, y) if (!is.null(x)) x else y


# ----------------------------------------------------------------------------
# 1. BUILD FREQUENCY SUMMARY
#    Scans all Parquet files and counts observations per vessel × device × week.
#    Returns a long tibble — used by both the plot and the table functions.
# ----------------------------------------------------------------------------

#' Scan Poseidat Parquet store and count observations per vessel/device/week
#'
#' @param base_dir      Character. Root of the Poseidat OneDrive folder.
#'                      Defaults to the ONEDRIVE_POSEIDAT environment variable.
#' @param sources       Character vector. Which source sub-folders to include.
#'                      Default: c("efice", "pefa").  Use NULL to include all.
#' @param start_date    Date or NULL.  Lower bound for weeks to include.
#' @param end_date      Date or NULL.  Upper bound.  Defaults to today.
#' @param vessel_config Tibble or NULL.  The vessel config object (from
#'                      Poseidat_config.R / poseidat_vessels.rds).  Must contain
#'                      columns \code{vessel_name} and \code{device_labels},
#'                      where \code{device_labels} is a list-column of named
#'                      character vectors: names = device_id, values = label.
#'                      If NULL (default), device UUIDs are shown unresolved.
#' @param device_label_chars  Integer. How many leading characters of the
#'                      device UUID to show when no label is available. Default 8.
#'
#' @return A tibble with columns:
#'   source, vessel_name, device_id, device_short, device_name,
#'   week_start (Monday of ISO week), year_week (label),
#'   n_obs, avg_interval_sec (mean seconds between consecutive observations)
#'
#' @examples
#' vessel_config <- readRDS(file.path(Sys.getenv("ONEDRIVE_POSEIDAT"),
#'                                    "config", "poseidat_vessels.rds"))
#' freq <- build_poseidat_frequency(vessel_config = vessel_config)
#' plot_poseidat_frequency(freq)
#' table_poseidat_frequency(freq)
build_poseidat_frequency <- function(
    base_dir           = Sys.getenv("ONEDRIVE_POSEIDAT"),
    sources            = c("efice", "pefa"),
    start_date         = NULL,
    end_date           = Sys.Date(),
    vessel_config      = NULL,
    device_label_chars = 8
) {

  if (!nzchar(base_dir)) stop("Set ONEDRIVE_POSEIDAT in .Renviron or pass base_dir.")

  # Collect Parquet files from raw/ and processed/ trees
  parquet_files <- character(0)

  for (tree in c("raw", "processed")) {
    tree_root <- file.path(base_dir, tree)
    if (!dir.exists(tree_root)) next

    # Restrict to requested sources (sub-folders directly under raw/ or processed/)
    candidates <- if (!is.null(sources)) {
      file.path(tree_root, sources)
    } else {
      list.dirs(tree_root, recursive = FALSE, full.names = TRUE)
    }

    for (src_dir in candidates[dir.exists(candidates)]) {
      parquet_files <- c(
        parquet_files,
        list.files(src_dir, pattern = "\\.parquet$",
                   recursive = TRUE, full.names = TRUE)
      )
    }
  }

  parquet_files <- unique(parquet_files)

  if (length(parquet_files) == 0) {
    message("No Parquet files found under ", base_dir)
    return(tibble())
  }

  message(sprintf("Reading %d Parquet file(s)...", length(parquet_files)))

  # Parse source and vessel from path structure:
  #   <base_dir>/(raw|processed)/<source>/<vessel>/.../<file>.parquet
  path_meta <- tibble(filepath = parquet_files) |>
    mutate(
      rel   = sub(paste0("^", normalizePath(base_dir, winslash = "/"), "/?"), "",
                  normalizePath(filepath, winslash = "/")),
      parts = strsplit(rel, "/")
    ) |>
    mutate(
      tree        = sapply(parts, `[[`, 1),
      source      = sapply(parts, function(p) if (length(p) >= 2) p[[2]] else NA_character_),
      vessel_name = sapply(parts, function(p) if (length(p) >= 3) p[[3]] else NA_character_)
    ) |>
    select(filepath, source, vessel_name)
  
  # t <- read_parquet(path_meta$filepath[1])
  
  # Read only the datetime column (+ entry_id for dedup) from each file
  safe_read <- function(fp) {
    tryCatch({
      cols_available <- arrow::open_dataset(fp)$schema$names
      cols_to_read <- intersect(c("datetime", "entry_id", "device_id"), cols_available)
      arrow::read_parquet(fp, col_select = all_of(cols_to_read))
    }, error = function(e) {
      message("  Skipping ", basename(fp), ": ", conditionMessage(e))
      NULL
    })
  }

  all_data <- purrr::map2_dfr(path_meta$filepath, seq_len(nrow(path_meta)), function(fp, i) {
    df <- safe_read(fp)
    if (is.null(df) || nrow(df) == 0) return(NULL)
    df |> mutate(
      filepath    = fp,
      source      = path_meta$source[i],
      vessel_name = path_meta$vessel_name[i]
    )
  })

  if (nrow(all_data) == 0) {
    message("Parquet files found but no readable rows.")
    return(tibble())
  }

  # Deduplicate on entry_id if present
  if ("entry_id" %in% names(all_data)) {
    all_data <- all_data |> distinct(entry_id, .keep_all = TRUE)
  }

  # Ensure datetime is POSIXct
  if (!"datetime" %in% names(all_data)) {
    stop("No 'datetime' column found in any Parquet file.")
  }
  all_data <- all_data |>
    mutate(datetime = as.POSIXct(datetime, tz = "UTC"))

  # Optional date filter
  if (!is.null(start_date)) {
    all_data <- all_data |> filter(as.Date(datetime) >= as.Date(start_date))
  }
  if (!is.null(end_date)) {
    all_data <- all_data |> filter(as.Date(datetime) <= as.Date(end_date))
  }

  # device_id: use column if present, else "unknown"
  if (!"device_id" %in% names(all_data)) {
    all_data <- all_data |> mutate(device_id = "unknown")
  }

  # Build a flat device_id → device_name lookup from vessel_config$device_labels.
  # device_labels is expected to be a list-column of named character vectors:
  #   names  = device_id (full UUID)
  #   values = human-readable label (e.g. "GPS", "Brandstofmeter", "Weegschaal")
  device_lookup <- if (!is.null(vessel_config) &&
                       "device_labels" %in% names(vessel_config)) {
    purrr::map2_dfr(
      vessel_config$vessel_name,
      vessel_config$device_labels,
      function(vname, labels) {
        if (is.null(labels) || length(labels) == 0) return(NULL)
        tibble(
          vessel_name = vname,
          device_id   = names(labels),
          device_name = unname(labels)
        )
      }
    )
  } else {
    tibble(vessel_name = character(), device_id = character(),
           device_name = character())
  }

  if (nrow(device_lookup) > 0) {
    message(sprintf("  Device labels loaded: %d entries from vessel_config",
                    nrow(device_lookup)))
  } else {
    message("  No device_labels found in vessel_config — UUIDs will be used as labels")
  }

  # Short device label for readability
  all_data <- all_data |>
    mutate(
      device_short = substr(device_id, 1, device_label_chars),
      week_start   = floor_date(as.Date(datetime), unit = "week", week_start = 1),
      year_week    = paste0(isoyear(datetime), "-W",
                            formatC(isoweek(datetime), width = 2, flag = "0"))
    )

  # Aggregate — n_obs and mean interval between consecutive observations
  freq <- all_data |>
    arrange(source, vessel_name, device_id, datetime) |>
    group_by(source, vessel_name, device_id, device_short, week_start, year_week) |>
    summarise(
      n_obs            = n(),
      avg_interval_sec = if (n() < 2) NA_real_ else
        mean(diff(as.numeric(datetime)), na.rm = TRUE),
      .groups = "drop"
    ) |>
    arrange(source, vessel_name, device_short, week_start)

  # Join device names from vessel_config lookup; fall back to short UUID
  freq <- freq |>
    left_join(device_lookup, by = c("vessel_name", "device_id")) |>
    mutate(device_name = ifelse(
      !is.na(device_name) & nzchar(device_name),
      device_name,
      device_short
    ))

  message(sprintf("✓ Frequency table built: %d rows (%d vessel×device×week combos)",
                  nrow(freq),
                  n_distinct(freq |> select(vessel_name, device_id))))
  message(sprintf("  Devices with labels: %d of %d",
                  sum(freq$device_name != freq$device_short),
                  n_distinct(freq |> select(vessel_name, device_id))))
  freq
}


# ----------------------------------------------------------------------------
# 2. HEATMAP PLOT
#    One panel per vessel; rows = devices; columns = weeks; fill = chosen metric
# ----------------------------------------------------------------------------

#' Plot observation frequency as a heatmap: devices × weeks, faceted by vessel
#'
#' @param freq       Tibble returned by build_poseidat_frequency().
#' @param metric     Character. Which metric to display:
#'                   \code{"n_obs"} (default) — number of observations per week;
#'                   \code{"avg_interval"} — mean time between observations,
#'                   shown in the most readable unit (seconds, minutes, or hours).
#' @param title      Plot title. NULL = auto-generated from metric.
#' @param log_scale  Logical. Use log10 colour scale?  Default TRUE (recommended
#'                   for n_obs when frequencies span orders of magnitude).
#'                   Ignored for avg_interval (always linear).
#' @param max_weeks  Integer. Show only this many most-recent weeks.
#'                   NULL = show all weeks.
#'
#' @return A ggplot2 object.
plot_poseidat_frequency <- function(
    freq,
    metric     = c("n_obs", "avg_interval"),
    title      = NULL,
    log_scale  = TRUE,
    max_weeks  = 26
) {
  metric <- match.arg(metric)

  if (nrow(freq) == 0) {
    message("Empty frequency table — nothing to plot.")
    return(invisible(NULL))
  }

  # Restrict to most recent N weeks if requested
  if (!is.null(max_weeks)) {
    recent_weeks <- freq |> distinct(week_start) |>
      arrange(desc(week_start)) |> slice_head(n = max_weeks) |>
      pull(week_start)
    freq <- freq |> filter(week_start %in% recent_weeks)
  }

  # Choose the display column and derive a readable unit for avg_interval
  if (metric == "n_obs") {
    freq <- freq |> mutate(.value = n_obs)
    legend_title  <- if (log_scale) "Obs (log10)" else "Observations"
    plot_title    <- title %||% "Poseidat observation count by vessel, device, and week"
    fill_scale <- if (log_scale) {
      scale_fill_viridis_c(
        name     = legend_title,
        option   = "C",
        na.value = "grey90",
        trans    = "log10",
        labels   = label_number(big.mark = ",")
      )
    } else {
      scale_fill_viridis_c(
        name     = legend_title,
        option   = "C",
        na.value = "grey90",
        labels   = label_number(big.mark = ",")
      )
    }
  } else {
    # Pick the most readable time unit based on median interval
    med_sec <- median(freq$avg_interval_sec, na.rm = TRUE)
    if (is.na(med_sec) || med_sec < 120) {
      unit_label <- "sec";   divisor <- 1
    } else if (med_sec < 7200) {
      unit_label <- "min";   divisor <- 60
    } else {
      unit_label <- "hours"; divisor <- 3600
    }
    freq <- freq |> mutate(.value = avg_interval_sec / divisor)
    plot_title <- title %||%
      "Poseidat mean interval between observations by vessel, device, and week"
    fill_scale <- scale_fill_viridis_c(
      name     = paste0("Avg interval\n(", unit_label, ")"),
      option   = "D",          # reversed direction: short interval = bright
      direction = -1,
      na.value = "grey90",
      labels   = label_number(accuracy = 0.1, big.mark = ",")
    )
  }

  # Complete grid so missing combos appear as NA (grey)
  freq_complete <- freq |>
    complete(
      nesting(source, vessel_name, device_id, device_short, device_name),
      week_start,
      fill = list(.value = NA)
    ) |>
    mutate(year_week = paste0(isoyear(week_start), "-W",
                              formatC(isoweek(week_start), width = 2, flag = "0")))

  # Device label: source + device_name (falls back to short UUID if no label)
  freq_complete <- freq_complete |>
    mutate(device_label = paste0(source, "\n", device_name))

  # Week axis: show every 2nd or 4th label to avoid crowding
  week_levels  <- sort(unique(freq_complete$week_start))
  n_weeks      <- length(week_levels)
  label_step   <- if (n_weeks > 20) 4 else if (n_weeks > 10) 2 else 1
  week_labels  <- ifelse(
    seq_along(week_levels) %% label_step == 1,
    format(week_levels, "%d %b"),
    ""
  )

  ggplot(freq_complete,
         aes(x = week_start, y = device_label, fill = .value)) +
    geom_tile(colour = "white", linewidth = 0.3) +
    facet_wrap(~ vessel_name, ncol = 1, scales = "free_y") +
    fill_scale +
    scale_x_date(
      breaks = week_levels,
      labels = week_labels,
      expand = expansion(add = 3)
    ) +
    labs(
      title   = plot_title,
      x       = NULL,
      y       = "Source / Device name",
      caption = paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M"))
    ) +
    theme_minimal(base_size = 10) +
    theme(
      axis.text.x        = element_text(angle = 45, hjust = 1, size = 7),
      axis.text.y        = element_text(size = 7),
      strip.text         = element_text(face = "bold", size = 9),
      panel.grid.major.x = element_blank(),
      panel.grid.minor   = element_blank(),
      legend.position    = "right",
      plot.title         = element_text(face = "bold")
    )
}


# ----------------------------------------------------------------------------
# 3. GT TABLE
#    Pivot wider: rows = vessel × device; columns = weeks; cells = formatted value
# ----------------------------------------------------------------------------

#' Display observation frequency as a gt table: vessels × devices as rows,
#' weeks as columns (most recent N weeks).
#'
#' @param freq       Tibble returned by build_poseidat_frequency().
#' @param metric     Character. Which metric to display:
#'                   \code{"n_obs"} (default) — number of observations;
#'                   \code{"avg_interval"} — mean time between observations,
#'                   formatted in the most readable unit (sec / min / hours).
#' @param max_weeks  Integer. Number of most recent weeks to display.
#' @param title      Table title string. NULL = auto-generated from metric.
#'
#' @return A gt table object (print to display or save with gtsave()).
table_poseidat_frequency <- function(
    freq,
    metric    = c("n_obs", "avg_interval"),
    max_weeks = 12,
    title     = NULL
) {
  metric <- match.arg(metric)

  if (nrow(freq) == 0) {
    message("Empty frequency table — nothing to display.")
    return(invisible(NULL))
  }

  # Determine display title and format function based on metric
  if (metric == "n_obs") {
    tbl_title  <- title %||% "Poseidat observations per vessel, device, and week"
    fmt_value  <- function(x) ifelse(is.na(x), "—",
                                     formatC(x, format = "d", big.mark = ","))
    col_footer <- "Observations"
  } else {
    med_sec <- median(freq$avg_interval_sec, na.rm = TRUE)
    if (is.na(med_sec) || med_sec < 120) {
      unit_label <- "sec";   divisor <- 1;    accuracy <- 1
    } else if (med_sec < 7200) {
      unit_label <- "min";   divisor <- 60;   accuracy <- 0.1
    } else {
      unit_label <- "hours"; divisor <- 3600; accuracy <- 0.01
    }
    tbl_title  <- title %||%
      paste0("Poseidat mean interval between observations per vessel, device, and week (",
             unit_label, ")")
    fmt_value  <- function(x) ifelse(is.na(x), "—",
                                     formatC(round(x / divisor, accuracy),
                                             format = "f",
                                             digits = nchar(sub(".*\\.", "", accuracy))))
    col_footer <- paste0("Avg interval (", unit_label, ")")
  }

  # Select most recent weeks
  recent_weeks <- freq |>
    distinct(week_start, year_week) |>
    arrange(desc(week_start)) |>
    slice_head(n = max_weeks) |>
    arrange(week_start)

  freq_filtered <- freq |>
    filter(week_start %in% recent_weeks$week_start)

  # Pivot wider: one column per week
  freq_wide <- freq_filtered |>
    mutate(
      .display = fmt_value(if (metric == "n_obs") n_obs else avg_interval_sec)
    ) |>
    pivot_wider(
      id_cols     = c(source, vessel_name, device_id, device_short, device_name),
      names_from  = year_week,
      values_from = .display,
      values_fill = "—"
    ) |>
    arrange(source, vessel_name, device_name)

  week_cols <- recent_weeks$year_week

  gt(freq_wide, rowname_col = "device_name", groupname_col = "vessel_name") |>
    tab_header(
      title    = tbl_title,
      subtitle = paste0(
        format(min(recent_weeks$week_start), "%d %b %Y"), " – ",
        format(max(recent_weeks$week_start), "%d %b %Y")
      )
    ) |>
    cols_hide(columns = c(device_id, device_short)) |>
    cols_label(
      source      = "Source",
      device_name = "Device"
    ) |>
    cols_align(align = "right",  columns = all_of(week_cols)) |>
    cols_align(align = "left",   columns = c(source, device_name)) |>
    tab_style(
      style     = cell_fill(color = "#f0f0f0"),
      locations = cells_row_groups()
    ) |>
    tab_style(
      style = cell_text(weight = "bold"),
      locations = cells_row_groups()
    ) |>
    tab_options(
      table.font.size      = px(12),
      row.striping.include_table_body = TRUE,
      row.striping.background_color   = "#fafafa"
    ) |>
    tab_source_note(
      source_note = paste0(col_footer, "  |  Generated: ",
                           format(Sys.time(), "%Y-%m-%d %H:%M"))
    )
}


# ============================================================================
# EXAMPLE USAGE (run interactively, not sourced automatically)
# ============================================================================
if (FALSE) {

  # Load vessel config (contains device_labels list-column)
  config_dir    <- file.path(Sys.getenv("ONEDRIVE_POSEIDAT"), "config")
  vessel_config <- readRDS(file.path(config_dir, "poseidat_vessels.rds"))

  # vessel_config$device_labels should be a list-column of named character vectors,
  # one entry per vessel row.  Example of how it is constructed in Poseidat_config.R:
  #
  #   vessel_config <- vessel_config |>
  #     mutate(device_labels = list(
  #       # Lub Senior
  #       c("3864776a-...0001" = "GPS",
  #         "3864776a-...0002" = "Brandstofmeter",
  #         "3864776a-...0007" = "Trekkrachtmeting"),
  #       # Polar
  #       c("abcd1234-...0001" = "GPS",
  #         "abcd1234-...0003" = "Weegschaal")
  #     ))

  # 1. Build the frequency summary (reads all Parquet files)
  #    Returns n_obs AND avg_interval_sec for every vessel × device × week
  freq <- build_poseidat_frequency(
    sources       = c("efice", "pefa"),
    start_date    = as.Date("2025-10-01"),
    end_date      = Sys.Date(),
    vessel_config = vessel_config
  )

  # 2a. Heatmap — observation count (log scale), last 16 weeks
  p1 <- plot_poseidat_frequency(freq, metric = "n_obs", max_weeks = 16)
  print(p1)

  # 2b. Heatmap — average interval between observations, last 16 weeks
  #     Colour scale auto-selects unit (sec / min / hours) based on median interval
  p2 <- plot_poseidat_frequency(freq, metric = "avg_interval", max_weeks = 16)
  print(p2)

  # 3a. GT table — observation count, last 12 weeks
  tbl1 <- table_poseidat_frequency(freq, metric = "n_obs",        max_weeks = 12)
  print(tbl1)

  # 3b. GT table — average interval, last 12 weeks
  tbl2 <- table_poseidat_frequency(freq, metric = "avg_interval", max_weeks = 12)
  print(tbl2)

  # Save plots / tables
  # ggsave(file.path(Sys.getenv("ONEDRIVE_POSEIDAT"), "reports",
  #                  paste0("poseidat_nobs_",     Sys.Date(), ".png")), p1,
  #        width = 14, height = 8, dpi = 150)
  # ggsave(file.path(Sys.getenv("ONEDRIVE_POSEIDAT"), "reports",
  #                  paste0("poseidat_interval_", Sys.Date(), ".png")), p2,
  #        width = 14, height = 8, dpi = 150)
  # gt::gtsave(tbl1, file.path(Sys.getenv("ONEDRIVE_POSEIDAT"),
  #                            "reports", "poseidat_nobs.html"))
  gt::gtsave(tbl2, file.path(Sys.getenv("ONEDRIVE_POSEIDAT"),
                             "outputs", "reports", "poseidat_interval.html"))

  # Quick look at a specific vessel
  freq |>
    filter(vessel_name == "Lub Senior") |>
    select(device_name, week_start, n_obs, avg_interval_sec) |>
    mutate(avg_interval_min = round(avg_interval_sec / 60, 1)) |>
    print(n = 40)
}

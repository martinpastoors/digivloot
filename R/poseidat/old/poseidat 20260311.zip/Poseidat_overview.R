# ============================================================================
# Poseidat_overview.R
#
# Easy overview functions for data stored in the Poseidat parquet files.
#
# Functions:
#   poseidat_files()        — list all parquet files with size and row counts
#   poseidat_value_types()  — what measurement types exist per vessel/device
#   poseidat_daily()        — daily record counts per vessel/device/value_type
#   poseidat_summary()      — min/mean/max per value_type per vessel
#   poseidat_filter_save()  — re-save parquet files keeping only chosen value_types
#
# All functions work across all sources (efice, pefa, dbmatic) and read
# directly from the parquet files — no API calls needed.
# ============================================================================

suppressPackageStartupMessages({
  library(arrow)
  library(dplyr)
  library(purrr)
  library(lubridate)
  library(fs)
})


# ============================================================================
# 1. poseidat_files()
#
# Lists every parquet file under raw/ and processed/ with its size,
# vessel, source, device, and row count.
# ============================================================================

poseidat_files <- function(source = NULL) {

  base <- .onedrive()

  files <- c(
    list.files(file.path(base, "raw"),       pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE),
    list.files(file.path(base, "processed"), pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE)
  )

  if (length(files) == 0) {
    message("No parquet files found under ", base)
    return(invisible(tibble()))
  }

  result <- map_dfr(files, function(f) {
    rel   <- sub(paste0(base, "/"), "", f, fixed = TRUE)
    parts <- strsplit(rel, "/")[[1]]
    tier  <- parts[1]                          # raw or processed
    src   <- if (length(parts) >= 2) parts[2] else NA_character_
    vsl   <- if (length(parts) >= 3) parts[3] else NA_character_

    rows  <- tryCatch(nrow(read_parquet(f)), error = \(e) NA_integer_)
    size  <- file.size(f)

    tibble(
      tier        = tier,
      source      = src,
      vessel_name = vsl,
      file        = basename(f),
      rows        = rows,
      size_kb     = round(size / 1024, 1),
      path        = f
    )
  })

  if (!is.null(source)) result <- filter(result, source %in% .env$source)

  result |>
    arrange(source, vessel_name, tier, file) |>
    dplyr::select(tier, source, vessel_name, file, rows, size_kb)
}


# ============================================================================
# 2. poseidat_value_types()
#
# Shows which value_types (FUEL_CONSUMPTION, POSITION, etc.) exist
# per vessel and device, with record counts and date range.
# ============================================================================

poseidat_value_types <- function(source = NULL) {

  base  <- .onedrive()
  files <- list.files(file.path(base, "raw"),       pattern = "\\.parquet$",
                      recursive = TRUE, full.names = TRUE)
  files <- c(files,
             list.files(file.path(base, "processed"), pattern = "\\.parquet$",
                        recursive = TRUE, full.names = TRUE))

  if (length(files) == 0) {
    message("No parquet files found")
    return(invisible(tibble()))
  }

  result <- map_dfr(files, function(f) {
    tryCatch({
      df <- read_parquet(f)
      if (!"value_type" %in% names(df)) return(tibble())
      df |>
        group_by(source, journal_id, device_id, value_type) |>
        summarise(
          n_records  = n(),
          first_obs  = min(datetime, na.rm = TRUE),
          last_obs   = max(datetime, na.rm = TRUE),
          .groups    = "drop"
        )
    }, error = \(e) tibble())
  })

  if (nrow(result) == 0) return(result)

  # Overlapping sync windows are handled by re-summing in group_by below
  result <- result |>
    group_by(source, journal_id, device_id, value_type) |>
    summarise(
      n_records = sum(n_records),
      first_obs = min(first_obs),
      last_obs  = max(last_obs),
      .groups   = "drop"
    )

  # Join vessel names from saved config (works for all sources)
  vessels <- tryCatch({
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    readRDS(cfg_path) |>
      dplyr::select(-device_labels) |>       # drop list-column before any dplyr ops
      dplyr::select(journal_id, vessel_name)
  }, error = function(e) tibble(journal_id = character(), vessel_name = character()))
  result <- left_join(result, vessels, by = "journal_id")

  if (!is.null(source)) result <- filter(result, source %in% .env$source)

  result |>
    arrange(source, vessel_name, device_id, value_type) |>
    dplyr::select(source, vessel_name, journal_id, device_id,
           value_type, n_records, first_obs, last_obs)
}


# ============================================================================
# 3. poseidat_daily()
#
# Daily record counts per vessel / device / value_type.
# Useful for spotting gaps in coverage.
#
# @param source      Filter to one source, or NULL for all
# @param vessel_name Filter to one vessel name, or NULL for all
# @param value_type  Filter to one value_type, or NULL for all
# ============================================================================

poseidat_daily <- function(source      = NULL,
                           vessel_name = NULL,
                           value_type  = NULL) {

  base  <- .onedrive()
  files <- c(
    list.files(file.path(base, "raw"),       pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE),
    list.files(file.path(base, "processed"), pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE)
  )

  if (length(files) == 0) {
    message("No parquet files found")
    return(invisible(tibble()))
  }

  result <- map_dfr(files, function(f) {
    tryCatch({
      df <- read_parquet(f)
      if (!all(c("datetime", "value_type", "source") %in% names(df)))
        return(tibble())

      # Apply filters early to keep memory low
      if (!is.null(source))      df <- filter(df, source      %in% .env$source)
      if (!is.null(value_type))  df <- filter(df, value_type  %in% .env$value_type)

      df |>
        mutate(date = as.Date(datetime)) |>
        group_by(source, journal_id, device_id, value_type, date) |>
        summarise(n_records = n(), .groups = "drop")
    }, error = \(e) tibble())
  })

  if (nrow(result) == 0) return(result)

  # Overlapping sync windows are handled by re-summing in group_by below
  result <- result |>
    group_by(source, journal_id, device_id, value_type, date) |>
    summarise(n_records = sum(n_records), .groups = "drop")

  # Join vessel names from saved config (works for all sources)
  vessels <- tryCatch({
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    readRDS(cfg_path) |>
      dplyr::select(-device_labels) |>       # drop list-column before any dplyr ops
      dplyr::select(journal_id, vessel_name)
  }, error = function(e) tibble(journal_id = character(), vessel_name = character()))
  result <- left_join(result, vessels, by = "journal_id")

  if (!is.null(vessel_name))
    result <- filter(result, vessel_name %in% .env$vessel_name)

  result |>
    arrange(source, vessel_name, device_id, value_type, date) |>
    dplyr::select(source, vessel_name, device_id, value_type, date, n_records)
}


# ============================================================================
# 4. poseidat_summary()
#
# Statistical summary (n, min, mean, max) per vessel / value_type.
# Only includes non-zero values to avoid sensor dropouts skewing averages.
#
# @param source     Filter to one source, or NULL for all
# @param value_type Filter to specific value_types, or NULL for all
# @param nonzero    If TRUE (default), exclude zero values from stats
# ============================================================================

poseidat_summary <- function(source     = NULL,
                             value_type = NULL,
                             nonzero    = TRUE) {

  base  <- .onedrive()
  files <- c(
    list.files(file.path(base, "raw"),       pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE),
    list.files(file.path(base, "processed"), pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE)
  )

  if (length(files) == 0) {
    message("No parquet files found")
    return(invisible(tibble()))
  }

  result <- map_dfr(files, function(f) {
    tryCatch({
      df <- read_parquet(f)
      if (!all(c("value_numeric", "value_type", "source") %in% names(df)))
        return(tibble())

      if (!is.null(source))     df <- filter(df, source     %in% .env$source)
      if (!is.null(value_type)) df <- filter(df, value_type %in% .env$value_type)
      if (nonzero)              df <- filter(df, value_numeric != 0)

      if (nrow(df) == 0) return(tibble())

      df |>
        group_by(source, journal_id, device_id, value_type) |>
        summarise(
          n         = n(),
          min_value = min(value_numeric,  na.rm = TRUE),
          mean_value= mean(value_numeric, na.rm = TRUE),
          max_value = max(value_numeric,  na.rm = TRUE),
          first_obs = min(datetime,       na.rm = TRUE),
          last_obs  = max(datetime,       na.rm = TRUE),
          .groups   = "drop"
        )
    }, error = \(e) tibble())
  })

  if (nrow(result) == 0) return(result)

  # Overlapping sync windows handled by re-aggregating across files below
  result <- result |>
    group_by(source, journal_id, device_id, value_type) |>
    summarise(
      n          = sum(n),
      min_value  = min(min_value),
      mean_value = sum(mean_value * n) / sum(n),      # weighted mean across files
      max_value  = max(max_value),
      first_obs  = min(first_obs),
      last_obs   = max(last_obs),
      .groups    = "drop"
    )

  vessels <- tryCatch({
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    readRDS(cfg_path) |>
      dplyr::select(-device_labels) |>       # drop list-column before any dplyr ops
      dplyr::select(journal_id, vessel_name)
  }, error = function(e) tibble(journal_id = character(), vessel_name = character()))
  result <- left_join(result, vessels, by = "journal_id")

  result |>
    arrange(source, vessel_name, value_type) |>
    dplyr::select(source, vessel_name, device_id, value_type,
           n, min_value, mean_value, max_value, first_obs, last_obs)
}


# ============================================================================
# 5. poseidat_filter_save()
#
# Re-reads all raw parquet files and re-saves them keeping only the
# specified value_types. Use this to slim down storage after you know
# which measurement types you actually need.
#
# @param keep_value_types Character vector of value_types to keep
#                         e.g. c("POSITION", "SPEED", "FUEL_CONSUMPTION")
# @param source           Filter to one source, or NULL for all
# @param dry_run          If TRUE, show what would be done without saving
# ============================================================================

poseidat_filter_save <- function(keep_value_types,
                                 source  = NULL,
                                 dry_run = TRUE) {

  base  <- .onedrive()
  files <- list.files(file.path(base, "raw"), pattern = "\\.parquet$",
                      recursive = TRUE, full.names = TRUE)

  if (!is.null(source)) {
    files <- files[grepl(paste0("/raw/", source, "/"), files, fixed = TRUE)]
  }

  if (length(files) == 0) {
    message("No raw parquet files found")
    return(invisible(NULL))
  }

  cat(sprintf("value_types to keep : %s\n",
              paste(keep_value_types, collapse = ", ")))
  cat(sprintf("Files to process    : %d\n", length(files)))
  if (dry_run) cat("DRY RUN — no files will be modified\n\n")

  for (f in files) {
    df_orig <- tryCatch(read_parquet(f), error = \(e) NULL)
    if (is.null(df_orig)) { cat(sprintf("  SKIP (unreadable): %s\n", basename(f))); next }

    df_filt <- filter(df_orig, value_type %in% keep_value_types)

    cat(sprintf("  %-60s  %d -> %d rows\n",
                basename(f), nrow(df_orig), nrow(df_filt)))

    if (!dry_run && nrow(df_filt) > 0) {
      write_parquet(df_filt, f)
    } else if (!dry_run && nrow(df_filt) == 0) {
      cat(sprintf("    WARNING: all rows removed — file not modified\n"))
    }
  }

  if (dry_run) {
    cat("\nSet dry_run = FALSE to apply the changes.\n")
  } else {
    cat("\nDone. Run poseidat_files() to verify new file sizes.\n")
  }
}




# ============================================================================
# 6. poseidat_thin()
#
# Summarises raw parquet data to a regular time interval (default 1 minute).
# Reduces storage and speeds up plotting without losing key patterns.
#
# Aggregation rules per value_type:
#   POSITION      -> mean lat/lon, last course/speed, max n_satellites
#   TRAWL_TENSION -> mean traction and shooted length per warp
#   All others    -> mean value_numeric
#
# @param source       Filter to one source, or NULL for all
# @param vessel_name  Filter to specific vessels, or NULL for all
# @param start_date   Date or NULL
# @param end_date     Date or NULL
# @param interval_min Aggregation interval in minutes (default 1)
# @param save         If TRUE, write thinned parquet files to processed/ folder
# ============================================================================

poseidat_thin <- function(source       = NULL,
                          vessel_name  = NULL,
                          start_date   = NULL,
                          end_date     = NULL,
                          interval_min = 1,
                          save         = FALSE) {

  base  <- .onedrive()
  files <- list.files(file.path(base, "raw"), pattern = "\\.parquet$",
                      recursive = TRUE, full.names = TRUE)

  if (!is.null(source))
    files <- files[grepl(paste0("/", source, "/"), files)]
  if (!is.null(vessel_name)) {
    pattern <- paste(gsub(" ", "_", vessel_name), collapse = "|")
    files   <- files[grepl(pattern, files)]
  }

  if (length(files) == 0) { message("No raw parquet files found"); return(invisible(tibble())) }

  result <- map_dfr(files, function(f) {
    tryCatch({
      df <- read_parquet(f)
      if (!"datetime" %in% names(df)) return(tibble())
      if (!is.null(start_date)) df <- filter(df, as.Date(datetime) >= start_date)
      if (!is.null(end_date))   df <- filter(df, as.Date(datetime) <= end_date)
      if (nrow(df) == 0)        return(tibble())

      # Deduplicate raw rows before aggregating (overlapping sync windows)
      df <- distinct(df, journal_id, device_id, datetime, .keep_all = TRUE)

      # Create time bin column
      secs <- interval_min * 60L
      df   <- df |>
        mutate(time_bin = as.POSIXct(
          floor(as.numeric(datetime) / secs) * secs,
          origin = "1970-01-01", tz = "UTC"
        ))

      # Aggregate differently per value_type
      has <- function(col) col %in% names(df)

      parts <- list()

      # Group by journal_id (not vessel_name — that column is not in raw parquet).
      # vessel_name is joined from config at the end.

      # POSITION
      if (has("latitude") && any(!is.na(df$latitude))) {
        parts[["position"]] <- df |>
          filter(value_type == "POSITION") |>
          group_by(source, journal_id, device_id, value_type, time_bin) |>
          summarise(
            latitude          = mean(latitude,          na.rm = TRUE),
            longitude         = mean(longitude,         na.rm = TRUE),
            course_made_good  = last(course_made_good),
            speed_over_ground = mean(speed_over_ground, na.rm = TRUE),
            n_satellites      = max(n_satellites,       na.rm = TRUE),
            n_raw             = n(),
            .groups           = "drop"
          )
      }

      # TRAWL_TENSION
      if (has("traction_port") && any(!is.na(df$traction_port))) {
        parts[["trawl"]] <- df |>
          filter(value_type == "TRAWL_TENSION") |>
          group_by(source, journal_id, device_id, value_type, time_bin) |>
          summarise(
            traction_port            = mean(traction_port,            na.rm = TRUE),
            traction_center          = mean(traction_center,          na.rm = TRUE),
            traction_starboard       = mean(traction_starboard,       na.rm = TRUE),
            shooted_length_port      = mean(shooted_length_port,      na.rm = TRUE),
            shooted_length_center    = mean(shooted_length_center,    na.rm = TRUE),
            shooted_length_starboard = mean(shooted_length_starboard, na.rm = TRUE),
            n_raw                    = n(),
            .groups                  = "drop"
          )
      }

      # All scalar types (FUEL, TEMPERATURE, DEPTH, etc.)
      scalar_types <- df |>
        filter(!value_type %in% c("POSITION", "TRAWL_TENSION"),
               !is.na(value_numeric)) |>
        pull(value_type) |> unique()

      if (length(scalar_types) > 0) {
        parts[["scalar"]] <- df |>
          filter(value_type %in% scalar_types) |>
          group_by(source, journal_id, device_id, value_type, time_bin) |>
          summarise(
            value_numeric = mean(value_numeric, na.rm = TRUE),
            n_raw         = n(),
            .groups       = "drop"
          )
      }

      bind_rows(parts) |>
        rename(datetime = time_bin)

    }, error = \(e) { message("Error in ", basename(f), ": ", e$message); tibble() })
  })

  if (nrow(result) == 0) { message("No data after thinning"); return(invisible(tibble())) }

  # Cross-file deduplication: if two overlapping parquet files produced binned
  # rows for the same time bin, re-average them. Split by value_type group to
  # avoid applying n_satellites max() to non-POSITION rows.
  group_cols <- c("source", "journal_id", "device_id", "value_type", "datetime")

  pos_result <- result |>
    filter(value_type == "POSITION") |>
    group_by(across(all_of(group_cols))) |>
    summarise(
      across(any_of(c("latitude", "longitude", "speed_over_ground")),
             \(x) mean(x, na.rm = TRUE)),
      across(any_of("course_made_good"), last),
      n_satellites = if ("n_satellites" %in% names(pick(everything())))
                       max(n_satellites, na.rm = TRUE) else NA_real_,
      n_raw = sum(n_raw, na.rm = TRUE),
      .groups = "drop"
    )

  trawl_result <- result |>
    filter(value_type == "TRAWL_TENSION") |>
    group_by(across(all_of(group_cols))) |>
    summarise(
      across(any_of(c("traction_port", "traction_center", "traction_starboard",
                      "shooted_length_port", "shooted_length_center",
                      "shooted_length_starboard")),
             \(x) mean(x, na.rm = TRUE)),
      n_raw = sum(n_raw, na.rm = TRUE),
      .groups = "drop"
    )

  scalar_result <- result |>
    filter(!value_type %in% c("POSITION", "TRAWL_TENSION")) |>
    group_by(across(all_of(group_cols))) |>
    summarise(
      value_numeric = mean(value_numeric, na.rm = TRUE),
      n_raw         = sum(n_raw, na.rm = TRUE),
      .groups       = "drop"
    )

  result <- bind_rows(pos_result, trawl_result, scalar_result)

  # Join vessel names from config (not stored in raw parquet files)
  vessels <- tryCatch({
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    readRDS(cfg_path) |>
      dplyr::select(-device_labels) |>       # drop list-column before any dplyr ops
      dplyr::select(journal_id, vessel_name)
  }, error = function(e) tibble(journal_id = character(), vessel_name = character()))
  result <- left_join(result, vessels, by = "journal_id")

  cat(sprintf("Thinned to %s records at %d-minute intervals\n",
              format(nrow(result), big.mark = ","), interval_min))

  if (save) {
    proc_dir <- file.path(base, "processed", "thinned")
    dir.create(proc_dir, recursive = TRUE, showWarnings = FALSE)
    out_file <- file.path(proc_dir,
                          sprintf("poseidat_thinned_%dmin_%s.parquet",
                                  interval_min,
                                  format(Sys.Date(), "%Y%m%d")))
    write_parquet(result, out_file)
    message(sprintf("Saved to: %s", out_file))
  }

  invisible(result)
}

# ============================================================================
# Quick usage examples — run these after sourcing this file
# ============================================================================

# # 1. What files exist and how big are they?
# poseidat_files()
#
# # 2. What value_types are stored per vessel/device?
# poseidat_value_types()
#
# # 3. Daily coverage — spot gaps
# poseidat_daily()
# poseidat_daily(vessel_name = "Lub Senior", value_type = "FUEL_CONSUMPTION")
#
# # 4. Statistical summary of non-zero measurements
# poseidat_summary()
# poseidat_summary(value_type = c("FUEL_CONSUMPTION", "TEMPERATURE"))
#
# # 5. See what would be removed if you kept only certain value_types
# poseidat_filter_save(
#   keep_value_types = c("POSITION", "SPEED", "FUEL_CONSUMPTION"),
#   dry_run = TRUE
# )
# # Then apply:
# poseidat_filter_save(
#   keep_value_types = c("POSITION", "SPEED", "FUEL_CONSUMPTION"),
#   dry_run = FALSE
# )


# ============================================================================
# 6. poseidat_positions()
#
# Load position data from parquet files, ready for mapping.
# Returns a tidy tibble with lat/lon and vessel name.
#
# @param source      Filter to one source, or NULL for all
# @param vessel_name Character vector of vessel names, or NULL for all
# @param start_date  Date or NULL
# @param end_date    Date or NULL
# @param thin_minutes Keep one position every N minutes (NULL = keep all)
# ============================================================================

poseidat_positions <- function(source       = NULL,
                               vessel_name  = NULL,
                               start_date   = NULL,
                               end_date     = NULL,
                               thin_minutes = NULL) {

  base  <- .onedrive()
  files <- c(
    list.files(file.path(base, "raw"),       pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE),
    list.files(file.path(base, "processed"), pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE)
  )

  if (!is.null(source)) {
    files <- files[grepl(paste0("/", source, "/"), files)]
  }
  if (!is.null(vessel_name)) {
    pattern <- paste(gsub(" ", "_", vessel_name), collapse = "|")
    files   <- files[grepl(pattern, files)]
  }

  if (length(files) == 0) { message("No parquet files found"); return(tibble()) }

  result <- map_dfr(files, function(f) {
    tryCatch({
      df <- read_parquet(f)
      if (!all(c("latitude", "longitude", "value_type") %in% names(df)))
        return(tibble())
      df <- filter(df, value_type == "POSITION",
                   !is.na(latitude), !is.na(longitude))
      if (!is.null(start_date)) df <- filter(df, as.Date(datetime) >= start_date)
      if (!is.null(end_date))   df <- filter(df, as.Date(datetime) <= end_date)
      df
    }, error = \(e) tibble())
  })

  if (nrow(result) == 0) {
    message("No POSITION records found — have you re-synced after the adapter update?")
    return(tibble())
  }

  # Remove duplicates from overlapping sync windows
  result <- distinct(result, journal_id, device_id, datetime, .keep_all = TRUE)

  # Join vessel names from config (not stored in raw parquet files)
  cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
  if (file.exists(cfg_path)) {
    vmap   <- readRDS(cfg_path)[, c("journal_id", "vessel_name")]
    result <- result |>
      dplyr::select(-any_of("vessel_name")) |>  # drop stale column if present
      left_join(vmap, by = "journal_id")
  } else {
    message("Config file not found: ", cfg_path)
    result <- mutate(result, vessel_name = NA_character_)
  }

  # Optional thinning: keep one record per vessel per N-minute bin
  if (!is.null(thin_minutes)) {
    result <- result |>
      mutate(time_bin = floor(as.numeric(datetime) / (thin_minutes * 60))) |>
      group_by(source, journal_id, time_bin) |>
      slice(1) |>
      ungroup() |>
      dplyr::select(-time_bin)
  }

  result |>
    arrange(vessel_name, datetime) |>
    dplyr::select(source, vessel_name, journal_id, datetime,
                  latitude, longitude, course_made_good,
                  speed_over_ground, n_satellites)
}


# ============================================================================
# 7. poseidat_map()
#
# Interactive leaflet map of vessel tracks, coloured by vessel.
# Requires: leaflet, leaflet.extras
#
# @param pos         Output of poseidat_positions(), or NULL to load all data
# @param thin_minutes Thin to one position every N minutes (default 5)
# ============================================================================

poseidat_map <- function(pos          = NULL,
                         thin_minutes = 5) {

  if (!requireNamespace("leaflet", quietly = TRUE))
    stop("Install leaflet: install.packages('leaflet')")

  library(leaflet)

  if (is.null(pos)) pos <- poseidat_positions(thin_minutes = thin_minutes)
  if (nrow(pos) == 0) { message("No position data to map"); return(invisible(NULL)) }

  # Ensure vessel_name is present and populated — join from config.
  # Always re-join to avoid stale NA vessel_name column from poseidat_positions().
  cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
  vmap     <- readRDS(cfg_path)[, c("journal_id", "vessel_name")]
  pos      <- pos |>
    dplyr::select(-any_of("vessel_name")) |>   # drop existing (possibly all-NA) column
    left_join(vmap, by = "journal_id")

  # Drop records where vessel_name could not be resolved
  pos <- dplyr::filter(pos, !is.na(vessel_name))
  if (nrow(pos) == 0) { message("No position data with resolved vessel names"); return(invisible(NULL)) }

  vessels <- unique(pos$vessel_name)
  colours <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3",
               "#FF7F00", "#A65628", "#F781BF")
  pal     <- setNames(colours[seq_along(vessels)], vessels)

  m <- leaflet(pos) |>
    addProviderTiles("CartoDB.Positron") |>
    addScaleBar(position = "bottomleft")

  # Add track line + markers per vessel
  for (vsl in vessels) {
    vdf <- filter(pos, vessel_name == vsl) |> arrange(datetime)
    col <- unname(pal[vsl])   # unname() extracts plain string for leaflet

    m <- m |>
      addPolylines(
        data      = vdf,
        lng       = ~longitude, lat = ~latitude,
        color     = col, weight = 1.5, opacity = 0.7,
        group     = vsl
      ) |>
      addCircleMarkers(
        data        = vdf,
        lng         = ~longitude, lat = ~latitude,
        radius      = 3, color = col, fillColor = col,
        fillOpacity = 0.8, stroke = FALSE,
        popup       = ~paste0(
          "<b>", vessel_name, "</b><br>",
          format(datetime, "%Y-%m-%d %H:%M"), "<br>",
          "SOG: ", round(speed_over_ground, 1), " kn<br>",
          "COG: ", round(course_made_good, 0), "°"
        ),
        group = vsl
      )
  }

  m |>
    addLayersControl(
      overlayGroups = vessels,
      options       = layersControlOptions(collapsed = FALSE)
    ) |>
    addLegend(
      position = "bottomright",
      colors   = pal[vessels],
      labels   = vessels,
      title    = "Vessel"
    )
}


# ============================================================================
# 8. poseidat_plot_timeseries()
#
# Time series plot of a numeric value_type per vessel.
# Requires: ggplot2
#
# @param value_type  Character. e.g. "FUEL_CONSUMPTION", "TOWING_FORCE"
# @param source      Filter to one source, or NULL for all
# @param vessel_name Filter to specific vessels, or NULL for all
# @param start_date  Date or NULL
# @param end_date    Date or NULL
# @param nonzero     If TRUE (default), exclude zero values
# @param thin_minutes Thin to one record per N minutes per vessel (NULL = all)
# ============================================================================

poseidat_plot_timeseries <- function(value_type,
                                     source       = NULL,
                                     vessel_name  = NULL,
                                     start_date   = NULL,
                                     end_date     = NULL,
                                     nonzero      = TRUE,
                                     thin_minutes = NULL) {

  if (!requireNamespace("ggplot2", quietly = TRUE))
    stop("Install ggplot2: install.packages('ggplot2')")

  library(ggplot2)

  base  <- .onedrive()
  files <- c(
    list.files(file.path(base, "raw"),       pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE),
    list.files(file.path(base, "processed"), pattern = "\\.parquet$",
               recursive = TRUE, full.names = TRUE)
  )

  if (!is.null(source))      files <- files[grepl(paste0("/", source, "/"), files)]
  if (!is.null(vessel_name)) {
    pattern <- paste(gsub(" ", "_", vessel_name), collapse = "|")
    files   <- files[grepl(pattern, files)]
  }

  if (length(files) == 0) { message("No parquet files found"); return(invisible(NULL)) }

  df <- map_dfr(files, function(f) {
    tryCatch({
      d <- read_parquet(f)
      if (!all(c("value_type", "value_numeric", "datetime") %in% names(d)))
        return(tibble())
      d <- filter(d, value_type %in% .env$value_type, !is.na(value_numeric))
      if (!is.null(start_date)) d <- filter(d, as.Date(datetime) >= start_date)
      if (!is.null(end_date))   d <- filter(d, as.Date(datetime) <= end_date)
      if (nonzero)              d <- filter(d, value_numeric != 0)
      d
    }, error = \(e) tibble())
  })

  if (nrow(df) == 0) {
    message("No non-zero records found for value_type: ", paste(value_type, collapse = ", "))
    return(invisible(NULL))
  }

  # Optional thinning
  if (!is.null(thin_minutes)) {
    df <- df |>
      mutate(time_bin = floor(as.numeric(datetime) / (thin_minutes * 60))) |>
      group_by(vessel_name, value_type, time_bin) |>
      summarise(value_numeric = mean(value_numeric, na.rm = TRUE),
                datetime = min(datetime), .groups = "drop") |>
      dplyr::select(-time_bin)
  }

  ggplot(df, aes(x = datetime, y = value_numeric, colour = vessel_name)) +
    geom_line(alpha = 0.6, linewidth = 0.4) +
    geom_point(alpha = 0.3, size = 0.8) +
    facet_wrap(~value_type, scales = "free_y", ncol = 1) +
    scale_colour_brewer(palette = "Set1", name = "Vessel") +
    labs(
      title = paste(paste(value_type, collapse = " / "), "over time"),
      x     = NULL,
      y     = "Value"
    ) +
    theme_bw() +
    theme(legend.position = "bottom")
}


# ============================================================================
# 9. poseidat_availability()
#
# Tile plot showing daily data availability per vessel and value_type.
# Green  = data present and non-zero/non-NA
# Orange = records exist but all zero or NA (sensor dropout / steaming)
# Grey   = no records at all for that day
#
# POSITION presence is based on non-NA latitude.
# TRAWL_TENSION presence is based on traction_center > 0.
# All other types use non-zero, non-NA value_numeric.
#
# @param source      Filter to one source, or NULL for all
# @param vessel_name Filter to specific vessels, or NULL for all
# @param start_date  Date or NULL
# @param end_date    Date or NULL
# ============================================================================

poseidat_availability <- function(source      = NULL,
                                  vessel_name = NULL,
                                  start_date  = NULL,
                                  end_date    = NULL) {

  if (!requireNamespace("ggplot2", quietly = TRUE))
    stop("Install ggplot2: install.packages('ggplot2')")

  # Load most recent thinned parquet if available, else fall back to raw
  thinned_files <- list.files(
    file.path(.onedrive(), "processed", "thinned"),
    pattern = "\\.parquet$", full.names = TRUE
  )

  if (length(thinned_files) > 0) {
    df <- read_parquet(sort(thinned_files) |> tail(1))
  } else {
    message("No thinned file found — reading raw parquet (may be slow)")
    raw_files <- list.files(file.path(.onedrive(), "raw"),
                            pattern = "\\.parquet$",
                            recursive = TRUE, full.names = TRUE)
    if (length(raw_files) == 0) {
      message("No parquet files found")
      return(invisible(NULL))
    }
    df <- map_dfr(raw_files, function(f) tryCatch(read_parquet(f),
                                                   error = \(e) tibble()))
  }

  if (nrow(df) == 0) { message("No data found"); return(invisible(NULL)) }

  # Join vessel names if not present
  if (!"vessel_name" %in% names(df) || all(is.na(df$vessel_name))) {
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    if (file.exists(cfg_path)) {
      vmap <- readRDS(cfg_path)[, c("journal_id", "vessel_name")]
      df   <- df |>
        dplyr::select(-any_of("vessel_name")) |>
        left_join(vmap, by = "journal_id")
    }
  }

  # Apply filters
  if (!is.null(source))      df <- filter(df, source      %in% .env$source)
  if (!is.null(vessel_name)) df <- filter(df, vessel_name %in% .env$vessel_name)
  if (!is.null(start_date))  df <- filter(df, as.Date(datetime) >= start_date)
  if (!is.null(end_date))    df <- filter(df, as.Date(datetime) <= end_date)

  if (nrow(df) == 0) { message("No data after filtering"); return(invisible(NULL)) }

  # Daily presence per vessel / value_type
  daily <- df |>
    mutate(date = as.Date(datetime)) |>
    group_by(vessel_name, value_type, date) |>
    summarise(
      n_total   = n(),
      n_nonzero = case_when(
        any(value_type == "POSITION")      ~ sum(!is.na(latitude),
                                                  na.rm = TRUE),
        any(value_type == "TRAWL_TENSION") ~ sum(!is.na(traction_center) &
                                                    traction_center > 0,
                                                  na.rm = TRUE),
        TRUE ~ sum(!is.na(value_numeric) & value_numeric != 0, na.rm = TRUE)
      ),
      .groups = "drop"
    ) |>
    mutate(
      status = case_when(
        n_nonzero > 0 ~ "data",
        n_total   > 0 ~ "zero / NA",
        TRUE          ~ "no data"
      )
    )

  # Fill in missing date/vessel/value_type combinations so gaps show as grey
  all_dates  <- seq(min(daily$date), max(daily$date), by = "day")
  all_combos <- tidyr::expand_grid(
    vessel_name = unique(daily$vessel_name),
    value_type  = unique(daily$value_type),
    date        = all_dates
  )

  daily_full <- left_join(all_combos, daily,
                          by = c("vessel_name", "value_type", "date")) |>
    mutate(status = tidyr::replace_na(status, "no data"))

  # Plot
  ggplot2::ggplot(daily_full,
                  ggplot2::aes(x = date, y = value_type, fill = status)) +
    ggplot2::geom_tile(colour = "white", linewidth = 0.2) +
    ggplot2::facet_wrap(~ vessel_name, ncol = 1) +
    ggplot2::scale_fill_manual(
      values = c(
        "data"      = "#4DAF4A",
        "zero / NA" = "#FF7F00",
        "no data"   = "grey90"
      )
    ) +
    ggplot2::scale_x_date(date_labels = "%d %b", date_breaks = "1 week") +
    ggplot2::labs(
      title   = "Daily data availability per vessel and value type",
      x       = NULL, y = NULL, fill = NULL,
      caption = sprintf("Generated: %s", Sys.Date())
    ) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      strip.text      = ggplot2::element_text(face = "bold"),
      panel.grid      = ggplot2::element_blank(),
      axis.text.x     = ggplot2::element_text(angle = 30, hjust = 1),
      legend.position = "bottom"
    )
}


# ============================================================================
# 10. poseidat_plot_trawl()
#
# Time series plot of TRAWL_TENSION data (traction per warp + shooted length).
# Reads from thinned parquet if available, raw parquet otherwise.
#
# @param vessel_name  Character vector of vessel names, or NULL for all
# @param start_date   Date or NULL
# @param end_date     Date or NULL
# @param towing_only  If TRUE (default), filter to traction_center > min_traction
# @param min_traction Minimum traction_center (kg) to consider as towing (default 500)
# @param show_length  If TRUE, add a second panel with shooted wire length
# ============================================================================

poseidat_plot_trawl <- function(vessel_name  = NULL,
                                start_date   = NULL,
                                end_date     = NULL,
                                towing_only  = TRUE,
                                min_traction = 500,
                                show_length  = FALSE) {

  if (!requireNamespace("ggplot2", quietly = TRUE))
    stop("Install ggplot2: install.packages('ggplot2')")

  # Load thinned parquet if available, else raw
  thinned_files <- list.files(
    file.path(.onedrive(), "processed", "thinned"),
    pattern = "\\.parquet$", full.names = TRUE
  )

  if (length(thinned_files) > 0) {
    df <- read_parquet(sort(thinned_files) |> tail(1))
  } else {
    raw_files <- list.files(file.path(.onedrive(), "raw"),
                            pattern = "\\.parquet$",
                            recursive = TRUE, full.names = TRUE)
    df <- map_dfr(raw_files, function(f) tryCatch(read_parquet(f),
                                                   error = \(e) tibble()))
  }

  # Join vessel names if missing
  if (!"vessel_name" %in% names(df) || all(is.na(df$vessel_name))) {
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    if (file.exists(cfg_path)) {
      vmap <- readRDS(cfg_path)[, c("journal_id", "vessel_name")]
      df   <- df |>
        dplyr::select(-any_of("vessel_name")) |>
        left_join(vmap, by = "journal_id")
    }
  }

  # Filter to TRAWL_TENSION only
  df <- filter(df, value_type == "TRAWL_TENSION")

  if (!is.null(vessel_name)) df <- filter(df, vessel_name %in% .env$vessel_name)
  if (!is.null(start_date))  df <- filter(df, as.Date(datetime) >= start_date)
  if (!is.null(end_date))    df <- filter(df, as.Date(datetime) <= end_date)

  if (nrow(df) == 0) {
    message("No TRAWL_TENSION data found for the given filters")
    return(invisible(NULL))
  }

  # Check required columns exist
  req_cols <- c("traction_port", "traction_center", "traction_starboard")
  if (!all(req_cols %in% names(df))) {
    message("TRAWL_TENSION columns not found — re-sync with updated adapter")
    return(invisible(NULL))
  }

  if (towing_only) df <- filter(df, traction_center > min_traction)

  if (nrow(df) == 0) {
    message(sprintf("No records with traction_center > %d kg", min_traction))
    return(invisible(NULL))
  }

  # Traction panel
  traction <- df |>
    tidyr::pivot_longer(
      cols      = c(traction_port, traction_center, traction_starboard),
      names_to  = "warp",
      values_to = "traction_kg"
    ) |>
    mutate(warp = recode(warp,
                         traction_port      = "Port",
                         traction_center    = "Center",
                         traction_starboard = "Starboard"))

  p_traction <- ggplot2::ggplot(
    traction,
    ggplot2::aes(x = datetime, y = traction_kg, colour = warp)
  ) +
    ggplot2::geom_line(alpha = 0.7, linewidth = 0.4) +
    ggplot2::facet_wrap(~ vessel_name, ncol = 1) +
    ggplot2::scale_colour_brewer(palette = "Set1", name = "Warp") +
    ggplot2::labs(
      title    = if (towing_only)
        sprintf("Trawl tension — towing only (traction center > %d kg)", min_traction)
      else
        "Trawl tension",
      x        = NULL,
      y        = "Traction (kg)",
      caption  = sprintf("Generated: %s", Sys.Date())
    ) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      strip.text      = ggplot2::element_text(face = "bold"),
      legend.position = "bottom"
    )

  if (!show_length) return(p_traction)

  # Optional shooted wire length panel
  length_cols <- c("shooted_length_port", "shooted_length_center",
                   "shooted_length_starboard")

  if (!all(length_cols %in% names(df))) {
    message("Shooted length columns not found — showing traction only")
    return(p_traction)
  }

  wire <- df |>
    tidyr::pivot_longer(
      cols      = all_of(length_cols),
      names_to  = "warp",
      values_to = "length_m"
    ) |>
    mutate(warp = recode(warp,
                         shooted_length_port      = "Port",
                         shooted_length_center    = "Center",
                         shooted_length_starboard = "Starboard"))

  p_length <- ggplot2::ggplot(
    wire,
    ggplot2::aes(x = datetime, y = length_m, colour = warp)
  ) +
    ggplot2::geom_line(alpha = 0.7, linewidth = 0.4) +
    ggplot2::facet_wrap(~ vessel_name, ncol = 1) +
    ggplot2::scale_colour_brewer(palette = "Set1", name = "Warp") +
    ggplot2::labs(x = NULL, y = "Shooted length (m)") +
    ggplot2::theme_bw() +
    ggplot2::theme(
      strip.text      = ggplot2::element_text(face = "bold"),
      legend.position = "none"
    )

  # Stack traction above wire length using patchwork if available
  if (requireNamespace("patchwork", quietly = TRUE)) {
    patchwork::wrap_plots(p_traction, p_length, ncol = 1, heights = c(2, 1))
  } else {
    message("Install patchwork for combined plot: install.packages('patchwork')")
    print(p_traction)
    print(p_length)
  }
}


# ============================================================================
# 11. poseidat_plot_overview()
#
# Facet grid plot showing all scalar value_types x all vessels in one view.
# Reads from the thinned parquet for speed.
# Rows = value_type, Columns = vessel_name.
#
# @param source      Filter to one source, or NULL for all
# @param vessel_name Filter to specific vessels, or NULL for all
# @param value_type  Filter to specific value_types, or NULL for all scalars
# @param start_date  Date or NULL
# @param end_date    Date or NULL
# @param nonzero     If TRUE (default), exclude zero/NA values
# @param scales      ggplot2 facet scales: "free_y" (default), "fixed", "free"
# ============================================================================

poseidat_plot_overview <- function(source      = NULL,
                                   vessel_name = NULL,
                                   value_type  = NULL,
                                   start_date  = NULL,
                                   end_date    = NULL,
                                   nonzero     = TRUE,
                                   scales      = "free_y") {

  if (!requireNamespace("ggplot2", quietly = TRUE))
    stop("Install ggplot2: install.packages('ggplot2')")

  # Load thinned parquet (fast); fall back to message if not available
  thinned_files <- list.files(
    file.path(.onedrive(), "processed", "thinned"),
    pattern = "\\.parquet$", full.names = TRUE
  )

  if (length(thinned_files) == 0) {
    message("No thinned file found -- run poseidat_thin(save=TRUE) first")
    return(invisible(NULL))
  }

  df <- read_parquet(sort(thinned_files) |> tail(1))

  if (nrow(df) == 0) { message("No data found"); return(invisible(NULL)) }

  # Join vessel names if missing
  if (!"vessel_name" %in% names(df) || all(is.na(df$vessel_name))) {
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    if (file.exists(cfg_path)) {
      vmap <- readRDS(cfg_path)[, c("journal_id", "vessel_name")]
      df   <- df |>
        dplyr::select(-any_of("vessel_name")) |>
        left_join(vmap, by = "journal_id")
    }
  }

  # Keep only scalar value_types (those with value_numeric)
  df <- df |>
    filter(!value_type %in% c("POSITION", "TRAWL_TENSION"),
           !is.na(value_numeric))

  if (nonzero) df <- filter(df, value_numeric != 0)

  # Apply filters
  if (!is.null(source))      df <- filter(df, source      %in% .env$source)
  if (!is.null(vessel_name)) df <- filter(df, vessel_name %in% .env$vessel_name)
  if (!is.null(value_type))  df <- filter(df, value_type  %in% .env$value_type)
  if (!is.null(start_date))  df <- filter(df, as.Date(datetime) >= start_date)
  if (!is.null(end_date))    df <- filter(df, as.Date(datetime) <= end_date)

  if (nrow(df) == 0) {
    message("No scalar data found after filtering")
    return(invisible(NULL))
  }

  n_types   <- length(unique(df$value_type))
  n_vessels <- length(unique(df$vessel_name))
  cat(sprintf("Plotting %d value_type(s) x %d vessel(s)\n", n_types, n_vessels))

  ggplot2::ggplot(df, ggplot2::aes(x = datetime, y = value_numeric,
                                    colour = vessel_name)) +
    ggplot2::geom_line(alpha = 0.6, linewidth = 0.3) +
    ggplot2::facet_grid(value_type ~ vessel_name, scales = scales) +
    ggplot2::scale_colour_brewer(palette = "Set1", guide = "none") +
    ggplot2::scale_x_datetime(date_labels = "%d %b", date_breaks = "1 week") +
    ggplot2::labs(
      title   = "Sensor data overview -- all value types x all vessels",
      x       = NULL,
      y       = NULL,
      caption = sprintf("Generated: %s  |  Source: thinned parquet", Sys.Date())
    ) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      strip.text.x     = ggplot2::element_text(face = "bold", size = 8),
      strip.text.y     = ggplot2::element_text(face = "bold", size = 7,
                                                angle = 0, hjust = 0),
      strip.background = ggplot2::element_rect(fill = "grey92"),
      axis.text.x      = ggplot2::element_text(angle = 30, hjust = 1, size = 7),
      axis.text.y      = ggplot2::element_text(size = 7),
      panel.spacing    = ggplot2::unit(0.3, "lines"),
      plot.title       = ggplot2::element_text(face = "bold")
    )
}


# ============================================================================
# 12. poseidat_plot_operational()
#
# Combined time series of the four key operational variables:
#   - FUEL_CONSUMPTION  (value_numeric, value_type == "FUEL_CONSUMPTION")
#   - SPEED             (speed_over_ground, value_type == "POSITION")
#   - TRACTION          (traction_center, value_type == "TRAWL_TENSION")
#   - DEPTH             (value_numeric, value_type == "DEPTH")
#
# Faceted as variable (rows) x vessel (columns).
# Reads from thinned parquet for speed.
#
# @param vessel_name Filter to specific vessels, or NULL for all
# @param start_date  Date or NULL
# @param end_date    Date or NULL
# @param nonzero     If TRUE (default), exclude zero values per variable
# @param scales      facet scales: "free_y" (default), "fixed", "free"
# ============================================================================

poseidat_plot_operational <- function(vessel_name = NULL,
                                      start_date  = NULL,
                                      end_date    = NULL,
                                      nonzero     = TRUE,
                                      scales      = "free_y") {

  if (!requireNamespace("ggplot2", quietly = TRUE))
    stop("Install ggplot2: install.packages('ggplot2')")

  # Load most recent thinned parquet
  thinned_files <- list.files(
    file.path(.onedrive(), "processed", "thinned"),
    pattern = "\\.parquet$", full.names = TRUE
  )

  if (length(thinned_files) == 0) {
    message("No thinned file found -- run poseidat_thin(save=TRUE) first")
    return(invisible(NULL))
  }

  df <- read_parquet(sort(thinned_files) |> tail(1))
  if (nrow(df) == 0) { message("No data found"); return(invisible(NULL)) }

  # Join vessel names if missing
  if (!"vessel_name" %in% names(df) || all(is.na(df$vessel_name))) {
    cfg_path <- file.path(.onedrive(), "config", "poseidat_vessels.rds")
    if (file.exists(cfg_path)) {
      vmap <- readRDS(cfg_path)[, c("journal_id", "vessel_name")]
      df   <- df |>
        dplyr::select(-any_of("vessel_name")) |>
        left_join(vmap, by = "journal_id")
    }
  }

  if (!is.null(vessel_name)) df <- filter(df, vessel_name %in% .env$vessel_name)
  if (!is.null(start_date))  df <- filter(df, as.Date(datetime) >= start_date)
  if (!is.null(end_date))    df <- filter(df, as.Date(datetime) <= end_date)

  if (nrow(df) == 0) { message("No data after filtering"); return(invisible(NULL)) }

  # Extract each variable into a common long format: datetime, vessel, variable, value
  extract <- function(data, vtype, col, label) {
    d <- data |>
      filter(value_type == vtype, !is.na(.data[[col]])) |>
      dplyr::select(vessel_name, datetime, value = all_of(col)) |>
      mutate(variable = label)
    if (nonzero) d <- filter(d, value != 0)
    d
  }

  long <- bind_rows(
    extract(df, "FUEL_CONSUMPTION", "value_numeric",    "Fuel consumption"),
    extract(df, "POSITION",         "speed_over_ground","Speed (SOG)"),
    extract(df, "TRAWL_TENSION",    "traction_center",  "Traction center"),
    extract(df, "DEPTH",            "value_numeric",    "Depth")
  )

  if (nrow(long) == 0) {
    message("No data found for any of the four operational variables")
    return(invisible(NULL))
  }

  # Fix factor order for rows: fuel, speed, traction, depth top to bottom
  long <- long |>
    mutate(variable = factor(variable,
                             levels = c("Fuel consumption", "Speed (SOG)",
                                        "Traction center", "Depth")))

  n_vars    <- length(unique(long$variable))
  n_vessels <- length(unique(long$vessel_name))
  cat(sprintf("Plotting %d variable(s) x %d vessel(s)\n", n_vars, n_vessels))

  ggplot2::ggplot(long, ggplot2::aes(x = datetime, y = value,
                                      colour = vessel_name)) +
    ggplot2::geom_line(alpha = 0.6, linewidth = 0.3) +
    ggplot2::facet_grid(variable ~ vessel_name, scales = scales) +
    ggplot2::scale_colour_brewer(palette = "Set1", guide = "none") +
    ggplot2::scale_x_datetime(date_labels = "%d %b", date_breaks = "1 week") +
    ggplot2::labs(
      title   = "Operational overview — fuel, speed, traction, depth",
      x       = NULL,
      y       = NULL,
      caption = sprintf("Generated: %s", Sys.Date())
    ) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      strip.text.x     = ggplot2::element_text(face = "bold", size = 9),
      strip.text.y     = ggplot2::element_text(face = "bold", size = 8,
                                                angle = 0, hjust = 0),
      strip.background = ggplot2::element_rect(fill = "grey92"),
      axis.text.x      = ggplot2::element_text(angle = 30, hjust = 1, size = 7),
      axis.text.y      = ggplot2::element_text(size = 7),
      panel.spacing    = ggplot2::unit(0.4, "lines"),
      plot.title       = ggplot2::element_text(face = "bold")
    )
}


# ============================================================================
# Quick usage examples
# ============================================================================

# # After re-syncing to get POSITION data with the updated adapter:
#
# # Map of all vessel tracks
# poseidat_map()
#
# # Map thinned to one position every 10 minutes
# poseidat_map(thin_minutes = 10)
#
# # Map for specific vessels and date range
# pos <- poseidat_positions(
#   vessel_name  = c("Lub Senior", "Polar"),
#   start_date   = as.Date("2026-02-20"),
#   end_date     = as.Date("2026-03-03"),
#   thin_minutes = 5
# )
# poseidat_map(pos)
#
# # Fuel consumption time series for all vessels
# poseidat_plot_timeseries("FUEL_CONSUMPTION")
#
# # Towing force for specific vessels
# poseidat_plot_timeseries(
#   value_type  = "TOWING_FORCE",
#   vessel_name = c("Lub Senior", "Willem Jacob"),
#   nonzero     = TRUE
# )
#
# # Multiple value types in one plot
# poseidat_plot_timeseries(c("FUEL_CONSUMPTION", "TOWING_FORCE"))

# # All vessels
# poseidat_plot_operational()
# 
# # Specific vessels and date range
# poseidat_plot_operational(
#   vessel_name = c("Willem Jacob"),
#   start_date  = as.Date("2026-02-23"),
#   end_date    = as.Date("2026-03-05")
# )
# # Poseidat data availability
# poseidat_availability()
#
# Read raw file
# files <- c(
#   list.files(file.path(.onedrive(), "raw"),       
#              pattern = "\\.parquet$",
#              recursive = TRUE, 
#              full.names = TRUE)
# )
# df <- read_parquet(sort(files) |> head(1))

# Read thinned file
# thinned_files <- list.files(
#   file.path(.onedrive(), "processed", "thinned"),
#   pattern = "\\.parquet$", full.names = TRUE
# )
# df <- read_parquet(sort(thinned_files) |> tail(1))

# df %>% 
#   group_by(vessel_name) %>% 
#   summarise(mindate = min(datetime, na.rm=TRUE),
#             maxdate = max(datetime, na.rm=TRUE))

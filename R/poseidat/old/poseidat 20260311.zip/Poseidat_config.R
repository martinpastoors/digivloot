# ============================================================================
# Poseidat_config.R
#
# Unified configuration for Poseidat data access.
# Supports three data sources, all providing the same Poseidat vessel journal
# sensor data (GPS, haul, engine measurements), just for different vessel /
# period combinations depending on which platform a vessel uses:
#   "dbmatic" — DBMatic API (test / sandbox data)
#   "efice"   — EFICE API  (production Poseidat data, EFICE-registered vessels)
#   "pefa"    — PEFA API   (production Poseidat data, PEFA-registered vessels)
#
# Run this script once to initialise. Edit vessel_config below to add vessels.
# ============================================================================

library(dplyr)

# ----------------------------------------------------------------------------
# OneDrive root — read from .Renviron (single source of truth).
# Set ONEDRIVE_POSEIDAT there; run usethis::edit_r_environ() to open it.
# ----------------------------------------------------------------------------
onedrive_base <- Sys.getenv("ONEDRIVE_POSEIDAT", unset = "")
if (!nzchar(onedrive_base)) {
  stop(
    "ONEDRIVE_POSEIDAT is not set.\n",
    "Add it to your .Renviron (usethis::edit_r_environ()):\n",
    "  ONEDRIVE_POSEIDAT = C:/Users/<you>/OneDrive/Poseidat"
  )
}

# ----------------------------------------------------------------------------
# Vessel configuration
#
# source      : "dbmatic" | "efice" | "pefa"
# journal_id  : Vessel identifier in the respective API
# vessel_name : Used as folder name — keep consistent
# cfr         : Community Fleet Register number
# enabled     : FALSE to skip during sync without deleting the row
#
# device_labels: Named list mapping device UUID -> friendly label.
#   Used for logging and folder naming only — does NOT restrict which
#   devices are synced. Devices are always discovered live from the API,
#   so if a device is replaced on a vessel, sync continues automatically.
#   Unknown devices (not in this list) are labelled by their UUID.
#
#   Format: list("uuid" = "LABEL", "uuid" = "LABEL", ...)
#   Labels should be short uppercase strings matching Poseidat value_types
#   where possible: POSITION, FUEL, TEMPERATURE, TOWING, ENGINE, etc.
#
#   To discover device UUIDs for a vessel, run:
#     get_devices("efice", journal_id)
#   To see which value_types each device produces, run:
#     poseidat_value_types()  # from Poseidat_overview.R
# ----------------------------------------------------------------------------

vessel_config <- tibble(
  source      = c(
    # DBMatic test vessels
    "dbmatic",
    # EFICE-registered vessels (confirmed journal IDs from get_vessels("efice"))
    "efice",
    "efice",
    "efice",
    # PEFA-registered vessels
    "pefa",
    "pefa"
  ),
  journal_id  = c(
    "21eacd08-fcd3-4665-9dba-9c23c325bfa3",   # DBMatic test vessel
    "6a5c162e-e967-41b6-9e8a-3cfddf5019b2",   # Lub Senior
    "a9294c48-ab38-4679-9dd5-f34003ba6b14",   # Polar
    "f4fc3064-fd63-4c9a-9635-0b292d534827",   # Willem Jacob
    "REPLACE-WITH-PEFA-JOURNAL-UUID-1",
    "REPLACE-WITH-PEFA-JOURNAL-UUID-2"
  ),
  vessel_name = c(
    "Test_Vessel_DBMatic",
    "Lub Senior",
    "Polar",
    "Willem Jacob",
    "Vessel_C",
    "Vessel_D"
  ),
  cfr = c(
    NA_character_,
    "UK-153",
    "UK-150",
    "UK-158",
    NA_character_,
    NA_character_
  ),
  enabled = c(
    FALSE,  # keep test vessel disabled in production runs
    TRUE,
    TRUE,
    TRUE,
    FALSE,  # enable once PEFA journal IDs are confirmed
    FALSE
  ),

  # Device label mapping — reference only, does not restrict sync.
  # Devices are always discovered live from the API.
  # Add/update labels here as you identify what each device measures.
  # Unknown devices are synced normally and labelled by their UUID.
  device_labels = list(
    # DBMatic test vessel — labels unknown, leave empty
    list(),

    # Lub Senior (UK-153) — 5 devices confirmed Feb 2026
    list(
      "6d336476-7931-7838-0000-000200000001" = "POSITION",
      "6d336476-7931-7838-0000-000200000005" = "FUEL_1",
      "6d336476-7931-7838-0000-000200000006" = "FUEL_2",
      "6d336476-7931-7838-0000-000200000007" = "FUEL_3",
      "6d336476-7931-7838-0000-000200000008" = "FUEL_4"
    ),

    # Polar (UK-150) — update labels once value_types confirmed
    list(
      "3864776a-3075-3271-0000-000200000001" = "POSITION",
      "3864776a-3075-3271-0000-000200000005" = "FUEL_1",
      "3864776a-3075-3271-0000-000200000006" = "FUEL_2",
      "3864776a-3075-3271-0000-000200000007" = "FUEL_3",
      "3864776a-3075-3271-0000-000200000008" = "FUEL_4"
    ),

    # Willem Jacob (UK-158) — update labels once value_types confirmed
    list(
      "61326139-7379-3463-0000-000200000001" = "POSITION",
      "61326139-7379-3463-0000-000200000004" = "DEPTH",
      "61326139-7379-3463-0000-000200000005" = "TRAWL_TENSION"
    ),

    # PEFA vessels — fill once journal IDs confirmed
    list(),
    list()
  )
)

# ----------------------------------------------------------------------------
# Helper: resolve a device UUID to its friendly label for a given vessel
#
# Usage:
#   get_device_label(vessel_config, "efice", journal_id, device_id)
#   # returns e.g. "POSITION" or the raw UUID if not in labels
# ----------------------------------------------------------------------------
get_device_label <- function(vessel_config, source, journal_id, device_id) {
  row <- vessel_config |>
    filter(source == .env$source, journal_id == .env$journal_id)
  if (nrow(row) == 0) return(device_id)
  labels <- row$device_labels[[1]]
  label  <- labels[[device_id]]
  if (is.null(label)) device_id else label
}

# ----------------------------------------------------------------------------
# Save config
# ----------------------------------------------------------------------------
config_dir <- file.path(onedrive_base, "config")
dir.create(config_dir, recursive = TRUE, showWarnings = FALSE)

saveRDS(vessel_config, file.path(config_dir, "poseidat_vessels.rds"))

message("✓ Poseidat config saved")
message(sprintf("  OneDrive base : %s", onedrive_base))
message(sprintf("  Vessels       : %d total (%d enabled)",
                nrow(vessel_config), sum(vessel_config$enabled)))

by_source <- vessel_config |>
  filter(enabled) |>
  count(source, name = "n")
for (i in seq_len(nrow(by_source))) {
  message(sprintf("    %-10s: %d vessel(s)", by_source$source[i], by_source$n[i]))
}

# Show device label summary for enabled vessels
message("\nDevice labels (reference — devices discovered live from API):")
for (i in seq_len(nrow(vessel_config))) {
  v <- vessel_config[i, ]
  if (!v$enabled) next
  labels <- v$device_labels[[1]]
  if (length(labels) == 0) {
    message(sprintf("  %-20s: (no labels defined)", v$vessel_name))
  } else {
    for (uuid in names(labels)) {
      message(sprintf("  %-20s: ...%s = %s",
                      v$vessel_name,
                      substr(uuid, nchar(uuid) - 7, nchar(uuid)),
                      labels[[uuid]]))
    }
  }
}

message("
.Renviron entries needed (usethis::edit_r_environ()):
  DBMATIC_API_URL   = https://api.dbmatic.eu/api/v1
  DBMATIC_TOKEN     = your-dbmatic-bearer-token
  EFICE_API_URL     = https://poseidat-journal.m-catch.com
  EFICE_TOKEN       = your-efice-bearer-token
  PEFA_API_URL      = https://...   (fill once confirmed)
  PEFA_TOKEN        = your-pefa-bearer-token
  ONEDRIVE_POSEIDAT = C:/Users/<you>/OneDrive/Poseidat")

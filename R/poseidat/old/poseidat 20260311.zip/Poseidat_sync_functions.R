# ============================================================================
# Poseidat_sync_functions.R
#
# Unified sync functions for Poseidat data from three sources:
#   "dbmatic" — DBMatic API  (test data,        known endpoint structure)
#   "efice"   — EFICE API    (production,        structure explored at runtime)
#   "pefa"    — PEFA API     (production,        structure explored at runtime)
#
# All three sources deliver the same Poseidat vessel journal sensor data
# (GPS positions, haul records, engine measurements, etc.).  The source
# reflects which platform a vessel is registered on, not a different data
# type.  EFICE and PEFA cover different vessel/period combinations.
#
# Architecture:
#   - One shared core (state, logging, storage, load, consolidate)
#   - Per-source API adapters:  .api_get_vessels(), .api_get_devices(),
#                               .api_get_measurements()
#   - Public sync functions call the core with the right adapter
#
# OneDrive folder layout:
#   <onedrive_base>/
#     config/                           sync state, vessel config
#     logs/                             monthly log files
#     raw/<source>/<vessel>/YYYY/MM/    incremental parquet per sync run
#     processed/<source>/<vessel>/YYYY/ monthly consolidated parquet
#
# Credentials — store in .Renviron (usethis::edit_r_environ()):
#   DBMATIC_API_URL   = https://api.dbmatic.eu/api/v1
#   DBMATIC_TOKEN     = your-dbmatic-token
#   EFICE_API_URL     = https://...    (fill once you have the URL)
#   EFICE_TOKEN       = your-efice-token
#   PEFA_API_URL      = https://...    (fill once you have the URL)
#   PEFA_TOKEN        = your-pefa-token
#   ONEDRIVE_POSEIDAT = C:/Users/<you>/OneDrive/Poseidat
# ============================================================================

suppressPackageStartupMessages({
  library(httr2)
  library(dplyr)
  library(purrr)
  library(glue)
  library(lubridate)
  library(arrow)
})


# ============================================================================
# SETUP
# ============================================================================

#' Configure the unified Poseidat sync
#'
#' Call once at the start of every session (or source this file).
#' Reads ONEDRIVE_POSEIDAT and all API credentials from .Renviron.
#' Stops with a clear message if ONEDRIVE_POSEIDAT is not set.
#' @export
setup_poseidat_sync <- function() {

  onedrive_base <- Sys.getenv("ONEDRIVE_POSEIDAT", unset = "")
  if (!nzchar(onedrive_base)) {
    stop(
      "ONEDRIVE_POSEIDAT is not set.\n",
      "Add it to your .Renviron (usethis::edit_r_environ()):\n",
      "  ONEDRIVE_POSEIDAT = C:/Users/<you>/OneDrive/Poseidat"
    )
  }

  options(poseidat_onedrive = onedrive_base)

  # Create directory skeleton
  for (d in c("config", "logs", "raw", "processed")) {
    dir.create(file.path(onedrive_base, d), recursive = TRUE, showWarnings = FALSE)
  }

  # Initialise state file
  state_file <- file.path(onedrive_base, "config", "sync_state.rds")
  if (!file.exists(state_file)) {
    saveRDS(list(created = Sys.time(), last_sync = NULL, vessels = list()),
            state_file)
    message("  Created initial sync state file")
  }

  # Validate credentials (warn, don't stop — user may only use one source)
  source_map <- list(
    DBMATIC_API_URL = "dbmatic", DBMATIC_TOKEN = "dbmatic",
    EFICE_API_URL   = "efice",   EFICE_TOKEN   = "efice",
    PEFA_API_URL    = "pefa",    PEFA_TOKEN    = "pefa"
  )
  for (var in names(source_map)) {
    if (!nzchar(Sys.getenv(var))) {
      message(sprintf("  ⚠ Env var %s not set (needed for %s source)",
                      var, source_map[[var]]))
    }
  }

  message("✓ Poseidat sync configured")
  message(sprintf("  OneDrive root : %s", onedrive_base))
}

.onedrive <- function() {
  od <- getOption("poseidat_onedrive", "")
  if (!nzchar(od)) stop("Poseidat not configured — run setup_poseidat_sync() first.")
  od
}


# ============================================================================
# LOGGING
# ============================================================================

#' Write timestamped log entry to monthly file and console
#'
#' @param msg       Character. Message text
#' @param level     Character. INFO | WARNING | ERROR
#' @param source    Character. "dbmatic" | "efice" | NULL
#' @param vessel_id Character. Optional journal UUID
log_poseidat <- function(msg, level = "INFO", source = NULL, vessel_id = NULL) {
  log_dir  <- file.path(.onedrive(), "logs")
  log_file <- file.path(log_dir,
                        sprintf("poseidat_sync_%s.log", format(Sys.Date(), "%Y%m")))
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)

  src_str    <- if (!is.null(source))    sprintf("[%s]",     source)    else ""
  vessel_str <- if (!is.null(vessel_id)) sprintf("[%s]", substr(vessel_id, 1, 8)) else ""
  entry <- sprintf("[%s] %s%s%s: %s\n",
                   format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
                   level, src_str, vessel_str, msg)
  cat(entry, file = log_file, append = TRUE)
  cat(entry)
}


# ============================================================================
# STATE MANAGEMENT
# ============================================================================

.state_file <- function() file.path(.onedrive(), "config", "sync_state.rds")

get_sync_state <- function() {
  f <- .state_file()
  if (file.exists(f)) return(readRDS(f))
  list(created = Sys.time(), last_sync = NULL, vessels = list())
}

save_sync_state <- function(state) {
  dir.create(dirname(.state_file()), recursive = TRUE, showWarnings = FALSE)
  saveRDS(state, .state_file())
  invisible(TRUE)
}

#' @param source    Character. "dbmatic" or "efice"
#' @param journal_id Character
#' @param device_id  Character
get_last_sync_time <- function(source, journal_id, device_id) {
  key   <- paste(source, journal_id, device_id, sep = "__")
  state <- get_sync_state()
  state$vessels[[key]]$last_sync_time   # NULL if not found
}

update_last_sync_time <- function(source, journal_id, device_id,
                                  sync_time, record_count = 0) {
  key   <- paste(source, journal_id, device_id, sep = "__")
  state <- get_sync_state()
  if (is.null(state$vessels)) state$vessels <- list()

  state$vessels[[key]] <- list(
    last_sync_time      = sync_time,
    last_sync_timestamp = Sys.time(),
    last_record_count   = record_count
  )
  state$last_sync <- Sys.time()
  save_sync_state(state)
  invisible(TRUE)
}


# ============================================================================
# GENERIC HTTP HELPER
# ============================================================================

#' Perform one authenticated GET request and return parsed JSON
#'
#' @param base_url  Character. API root URL (no trailing slash)
#' @param api_token Character. Bearer token
#' @param endpoint  Character. Path fragment appended to base_url
#' @param params    List.      Named query parameters (NULLs removed)
#' @return Parsed JSON (list)
.http_get <- function(base_url, api_token, endpoint, params = list()) {

  params <- compact(params)

  resp <- request(paste0(base_url, "/", endpoint)) |>
    req_auth_bearer_token(api_token) |>
    req_url_query(!!!params, .multi = "comma") |>
    req_error(is_error = \(r) FALSE) |>
    req_retry(max_tries = 3, backoff = ~ 5) |>
    req_perform()

  if (resp_status(resp) >= 400) {
    stop(sprintf(
      "API error %d (%s) on %s: %s",
      resp_status(resp), resp_status_desc(resp),
      endpoint, resp_body_string(resp)
    ))
  }

  resp_body_json(resp)
}


# ============================================================================
# API ADAPTERS
# Each adapter exposes three functions with a common signature:
#   .api_get_vessels(base_url, token)         → tibble(journal_id, vessel_name, ...)
#   .api_get_devices(base_url, token, jid)    → tibble(device_id, device_name, ...)
#   .api_get_measurements(base_url, token,    → tibble (measurements)
#                         jid, did, start, end, page_size, offset)
# ============================================================================

# ---- DBMatic adapter -------------------------------------------------------

.dbmatic_get_vessels <- function(base_url, token) {
  data <- .http_get(base_url, token, "journals")
  if (length(data) == 0) return(tibble(journal_id = character(),
                                       vessel_name = character(),
                                       cfr         = character(),
                                       flag_state  = character()))
  map_dfr(data, function(j) tibble(
    journal_id  = j$journal_id        %||% NA_character_,
    vessel_name = j$vessel$name        %||% NA_character_,
    flag_state  = j$vessel$flag_state  %||% NA_character_,
    cfr         = j$vessel$cfr         %||% NA_character_
  ))
}

.dbmatic_get_devices <- function(base_url, token, journal_id) {
  data <- .http_get(base_url, token,
                    glue("journals/{journal_id}/equipment_inventory"))
  equip_list <- data$equipment
  if (is.null(equip_list) || length(equip_list) == 0) return(tibble())

  map_dfr(equip_list, function(e) {
    if (is.null(e$devices) || length(e$devices) == 0) return(tibble())
    map_dfr(e$devices, function(d) tibble(
      equipment_id   = e$equipment_id  %||% NA_character_,
      equipment_name = e$name          %||% NA_character_,
      device_id      = d$device_id     %||% NA_character_,
      device_name    = d$name          %||% NA_character_,
      device_type    = d$type          %||% NA_character_
    ))
  }) |> filter(!is.na(device_id))
}

.dbmatic_get_measurements <- function(base_url, token,
                                       journal_id, device_id,
                                       start_time, end_time,
                                       page_size = 1000, offset = 0) {
  data <- .http_get(
    base_url, token,
    glue("journals/{journal_id}/measurements/{device_id}"),
    params = list(
      start  = as.integer(as.numeric(start_time)),
      end    = as.integer(as.numeric(end_time)),
      limit  = page_size,
      offset = offset
    )
  )
  if (length(data) == 0) return(tibble())

  map_dfr(data, function(rec) tibble(
    entry_id    = rec$entry_id    %||% NA_character_,
    datetime    = if (!is.null(rec$datetime))
      as.POSIXct(rec$datetime, format = "%Y-%m-%dT%H:%M:%S", tz = "UTC")
    else as.POSIXct(NA),
    value       = if (!is.null(rec$value))  as.numeric(rec$value)  else NA_real_,
    unit        = rec$unit        %||% NA_character_,
    sensor_type = rec$sensor_type %||% NA_character_,
    latitude    = if (!is.null(rec$latitude))  as.numeric(rec$latitude)  else NA_real_,
    longitude   = if (!is.null(rec$longitude)) as.numeric(rec$longitude) else NA_real_
  ))
}


# ---- EFICE adapter ---------------------------------------------------------
# Confirmed endpoint structure: poseidat-journal.m-catch.com
#
# GET /journals                  -> vessel list
#   response: { items: [{ journal_id, vessel: { name, flag_state,
#                          hull_number } }], limit, skip, total }
#
# GET /journals/entries          -> measurements
#   REQUIRED params: journalId (camelCase), startDate, endDate (ISO datetime)
#   optional params: deviceId, limit, skip, sortBy, sortDirection
#   NOTE: returns 0 records without startDate/endDate — effectively required.
#
# Key differences from DBMatic:
#   - No separate device endpoint; device UUIDs discovered from entry samples
#   - Pagination: limit / skip  (not page_size / offset)
#   - Datetime params: startDate / endDate  (ISO "2025-01-01T00:00:00Z")
#   - journalId / deviceId are camelCase in query params
#   - POSITION records use value$position$* instead of value$numeric$value

.efice_get_vessels <- function(base_url, token) {
  data  <- .http_get(base_url, token, "journals")
  items <- data$items %||% list()

  if (length(items) == 0) return(tibble(journal_id  = character(),
                                        vessel_name = character(),
                                        cfr         = character(),
                                        flag_state  = character()))
  map_dfr(items, function(v) tibble(
    journal_id  = as.character(v$journal_id        %||% NA_character_),
    vessel_name = as.character(v$vessel$name        %||% NA_character_),
    cfr         = as.character(v$vessel$hull_number %||% NA_character_),
    flag_state  = as.character(v$vessel$flag_state  %||% "NLD")
  ))
}

.efice_get_devices <- function(base_url, token, journal_id) {
  # EFICE has no dedicated device endpoint.
  # Device UUIDs are discovered by sampling recent entries.
  # startDate/endDate are effectively required — use a 90-day lookback.
  end_dt   <- format(Sys.time(),               "%Y-%m-%dT%H:%M:%SZ")
  start_dt <- format(Sys.time() - 90 * 86400,  "%Y-%m-%dT%H:%M:%SZ")

  data  <- .http_get(base_url, token, "journals/entries",
                     params = list(
                       journalId     = journal_id,
                       startDate     = start_dt,
                       endDate       = end_dt,
                       limit         = 200,
                       skip          = 0,
                       sortBy        = "entry_datetime",
                       sortDirection = "descending"
                     ))
  items <- data$items %||% list()

  if (length(items) == 0) return(tibble(device_id   = character(),
                                        device_name = character(),
                                        device_type = character()))

  device_ids <- unique(map_chr(items,
                               \(x) as.character(x$device_id %||% NA_character_)))
  device_ids <- device_ids[!is.na(device_ids)]

  tibble(
    device_id   = device_ids,
    device_name = device_ids,   # EFICE provides no human-readable device name
    device_type = "device-measurement"
  )
}

.efice_get_measurements <- function(base_url, token,
                                     journal_id, device_id,
                                     start_time, end_time,
                                     page_size = 1000, offset = 0) {
  fmt_dt <- function(t) format(as.POSIXct(t, tz = "UTC"), "%Y-%m-%dT%H:%M:%SZ")

  data  <- .http_get(base_url, token, "journals/entries",
                     params = list(
                       journalId     = journal_id,
                       deviceId      = device_id,
                       startDate     = fmt_dt(start_time),
                       endDate       = fmt_dt(end_time),
                       limit         = page_size,
                       skip          = offset,
                       sortBy        = "entry_datetime",
                       sortDirection = "ascending"
                     ))
  items <- data$items %||% list()
  if (length(items) == 0) return(tibble())

  map_dfr(items, function(rec) {
    # Three distinct value structures depending on value$type:
    #   POSITION      -> value$position$latitude, longitude, course_made_good,
    #                    speed_over_ground, number_of_satellites
    #   TRAWL_TENSION -> value$trawl_tension$traction_port/center/starboard,
    #                    shooted_length_port/center/starboard
    #   All others    -> value$numeric$value  (FUEL, TEMPERATURE, DEPTH, etc.)
    vtype        <- rec$value$type %||% NA_character_
    is_position  <- identical(vtype, "POSITION")
    is_trawl     <- identical(vtype, "TRAWL_TENSION")
    tt           <- rec$value$trawl_tension  # shorthand

    tibble(
      entry_id               = as.character(rec$entry_id       %||% NA_character_),
      datetime               = as.POSIXct(rec$entry_datetime   %||% NA_character_,
                                          format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
      revision               = as.POSIXct(rec$revision         %||% NA_character_,
                                          format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
      journal_id             = as.character(rec$journal_id     %||% NA_character_),
      device_id              = as.character(rec$device_id      %||% NA_character_),
      entry_type             = as.character(rec$entry_type     %||% NA_character_),
      value_type             = as.character(vtype),
      # Numeric value — for simple scalar measurements (FUEL, TEMPERATURE, DEPTH, etc.)
      value_numeric          = if (is_position || is_trawl) NA_real_ else
                                 as.numeric(rec$value$numeric$value %||% NA_real_),
      # POSITION fields
      latitude               = if (is_position)
                                 as.numeric(rec$value$position$latitude             %||% NA_real_)
                               else NA_real_,
      longitude              = if (is_position)
                                 as.numeric(rec$value$position$longitude            %||% NA_real_)
                               else NA_real_,
      course_made_good       = if (is_position)
                                 as.numeric(rec$value$position$course_made_good     %||% NA_real_)
                               else NA_real_,
      speed_over_ground      = if (is_position)
                                 as.numeric(rec$value$position$speed_over_ground    %||% NA_real_)
                               else NA_real_,
      n_satellites           = if (is_position)
                                 as.integer(rec$value$position$number_of_satellites %||% NA_integer_)
                               else NA_integer_,
      # TRAWL_TENSION fields
      traction_port          = if (is_trawl)
                                 as.numeric(tt$traction_port          %||% NA_real_)
                               else NA_real_,
      traction_center        = if (is_trawl)
                                 as.numeric(tt$traction_center        %||% NA_real_)
                               else NA_real_,
      traction_starboard     = if (is_trawl)
                                 as.numeric(tt$traction_starboard     %||% NA_real_)
                               else NA_real_,
      shooted_length_port    = if (is_trawl)
                                 as.numeric(tt$shooted_length_port    %||% NA_real_)
                               else NA_real_,
      shooted_length_center  = if (is_trawl)
                                 as.numeric(tt$shooted_length_center  %||% NA_real_)
                               else NA_real_,
      shooted_length_starboard = if (is_trawl)
                                 as.numeric(tt$shooted_length_starboard %||% NA_real_)
                               else NA_real_,
      immutable              = isTRUE(rec$immutable)
    )
  })
}


# ---- PEFA adapter ----------------------------------------------------------
# PEFA is another distribution channel for Poseidat vessel journal data —
# the same sensor measurements (GPS, haul, engine, etc.) as EFICE, but
# covering different vessel/period combinations depending on which vessels
# are registered through PEFA.
#
# The endpoint structure below mirrors the EFICE adapter (which itself
# mirrors DBMatic).  Use sandbox Section E to probe the actual PEFA API
# and update only these three functions if the endpoints or field names
# differ — the core sync logic requires no changes.

.pefa_get_vessels <- function(base_url, token) {
  tryCatch(
    .dbmatic_get_vessels(base_url, token),
    error = function(e) stop(paste(
      "PEFA get_vessels failed. The endpoint may differ from DBMatic.",
      "Use the sandbox to explore. Original error:", e$message
    ))
  )
}

.pefa_get_devices <- function(base_url, token, journal_id) {
  tryCatch(
    .dbmatic_get_devices(base_url, token, journal_id),
    error = function(e) stop(paste(
      "PEFA get_devices failed. Check endpoint in sandbox.",
      "Original error:", e$message
    ))
  )
}

.pefa_get_measurements <- function(base_url, token,
                                    journal_id, device_id,
                                    start_time, end_time,
                                    page_size = 1000, offset = 0) {
  tryCatch(
    .dbmatic_get_measurements(base_url, token, journal_id, device_id,
                               start_time, end_time, page_size, offset),
    error = function(e) stop(paste(
      "PEFA get_measurements failed. Check endpoint in sandbox.",
      "Original error:", e$message
    ))
  )
}


# ---- Adapter dispatcher (updated) ------------------------------------------

.get_adapter <- function(source) {
  switch(source,
    dbmatic = list(
      base_url      = Sys.getenv("DBMATIC_API_URL"),
      token         = Sys.getenv("DBMATIC_TOKEN"),
      get_vessels   = .dbmatic_get_vessels,
      get_devices   = .dbmatic_get_devices,
      get_meas      = .dbmatic_get_measurements
    ),
    efice = list(
      base_url      = Sys.getenv("EFICE_API_URL"),
      token         = Sys.getenv("EFICE_TOKEN"),
      get_vessels   = .efice_get_vessels,
      get_devices   = .efice_get_devices,
      get_meas      = .efice_get_measurements
    ),
    pefa = list(
      base_url      = Sys.getenv("PEFA_API_URL"),
      token         = Sys.getenv("PEFA_TOKEN"),
      get_vessels   = .pefa_get_vessels,
      get_devices   = .pefa_get_devices,
      get_meas      = .pefa_get_measurements
    ),
    stop(sprintf("Unknown source '%s'. Use 'dbmatic', 'efice', or 'pefa'.", source))
  )
}


# ============================================================================
# PUBLIC DISCOVERY FUNCTIONS
# ============================================================================

#' List accessible vessels for a given source
#'
#' @param source Character. "dbmatic" or "efice"
#' @return Tibble with journal_id, vessel_name, cfr, flag_state
#' @export
get_vessels <- function(source) {
  adp <- .get_adapter(source)
  message(sprintf("Fetching vessels from %s ...", source))
  vessels <- adp$get_vessels(adp$base_url, adp$token)
  message(sprintf("✓ Found %d vessel(s)", nrow(vessels)))
  vessels
}

#' List devices on a vessel
#'
#' @param source     Character. "dbmatic" or "efice"
#' @param journal_id Character. Vessel journal UUID
#' @return Tibble with device_id, device_name, device_type, equipment details
#' @export
get_devices <- function(source, journal_id) {
  adp <- .get_adapter(source)
  message(sprintf("Fetching devices for %s / %s ...", source, journal_id))
  devices <- adp$get_devices(adp$base_url, adp$token, journal_id)
  message(sprintf("✓ Found %d device(s)", nrow(devices)))
  devices
}

#' Look up a vessel's journal_id from vessel_config by vessel name
#'
#' @param vessel_config Tibble. From Poseidat_config.R / readRDS()
#' @param vessel_name   Character. Exact vessel name as in config
#' @return Character journal_id
#' @export
get_journal_id <- function(vessel_config, vessel_name) {
  row <- vessel_config |> filter(vessel_name == .env$vessel_name)
  if (nrow(row) == 0)
    stop(sprintf("Vessel not found in config: '%s'", vessel_name))
  row$journal_id
}

#' Look up a device UUID from vessel_config by vessel name and label
#'
#' Searches the device_labels list in vessel_config for the given label
#' and returns the matching UUID. Labels are defined in Poseidat_config.R.
#'
#' @param vessel_config Tibble. From Poseidat_config.R / readRDS()
#' @param vessel_name   Character. Exact vessel name as in config
#' @param label         Character. Device label e.g. "POSITION", "FUEL_1"
#' @return Character device UUID
#' @export
get_device_by_label <- function(vessel_config, vessel_name, label) {
  row <- vessel_config |> filter(vessel_name == .env$vessel_name)
  if (nrow(row) == 0)
    stop(sprintf("Vessel not found in config: '%s'", vessel_name))
  labels <- row$device_labels[[1]]
  if (length(labels) == 0)
    stop(sprintf("No device labels defined for vessel: '%s'", vessel_name))
  uuid <- names(labels)[unlist(labels) == label]
  if (length(uuid) == 0)
    stop(sprintf("Label '%s' not found for vessel '%s'. Available: %s",
                 label, vessel_name,
                 paste(unlist(labels), collapse = ", ")))
  if (length(uuid) > 1) {
    warning(sprintf("Multiple devices match label '%s' — returning first", label))
    uuid <- uuid[1]
  }
  uuid
}

#' List all device labels defined in vessel_config for a vessel
#'
#' @param vessel_config Tibble. From Poseidat_config.R / readRDS()
#' @param vessel_name   Character. Exact vessel name, or NULL for all vessels
#' @return Tibble with vessel_name, device_id, label
#' @export
list_device_labels <- function(vessel_config, vessel_name = NULL) {
  cfg <- vessel_config
  if (!is.null(vessel_name))
    cfg <- filter(cfg, vessel_name %in% .env$vessel_name)

  map_dfr(seq_len(nrow(cfg)), function(i) {
    v      <- cfg[i, ]
    labels <- v$device_labels[[1]]
    if (length(labels) == 0)
      return(tibble(vessel_name = v$vessel_name,
                    source      = v$source,
                    device_id   = NA_character_,
                    label       = NA_character_))
    tibble(
      vessel_name = v$vessel_name,
      source      = v$source,
      device_id   = names(labels),
      label       = unlist(labels)
    )
  })
}


# ============================================================================
# STORAGE PATH HELPERS
# ============================================================================

# raw/<source>/<vessel>/YYYY/MM/<vessel>_<device>_YYYYMMDD_to_YYYYMMDD.parquet
# processed/<source>/<vessel>/YYYY/<vessel>_<device>_YYYYMM.parquet

.safe <- function(x) gsub("[^a-zA-Z0-9_-]", "_", x)

.raw_dir <- function(source, vessel_name)
  file.path(.onedrive(), "raw", source, vessel_name)

.proc_dir <- function(source, vessel_name)
  file.path(.onedrive(), "processed", source, vessel_name)

.raw_path <- function(source, vessel_name, device_id, year, month,
                      data_start, data_end) {
  # Folder and filename based on ACTUAL data dates, not the requested window.
  # This ensures force_full syncs land in the correct YYYY/MM folders.
  dir <- file.path(.raw_dir(source, vessel_name),
                   sprintf("%04d", year),
                   sprintf("%02d", month))
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  file.path(dir, sprintf("%s_%s_%s_to_%s.parquet",
                         .safe(vessel_name), .safe(device_id),
                         format(data_start, "%Y%m%d"),
                         format(data_end,   "%Y%m%d")))
}

# Split a downloaded tibble by calendar month and save one parquet per month.
# Returns a character vector of file paths written.
.save_by_month <- function(measurements, source, vessel_name, device_id) {
  measurements <- measurements |>
    mutate(.year  = as.integer(format(datetime, "%Y")),
           .month = as.integer(format(datetime, "%m")))

  months <- measurements |>
    distinct(.year, .month) |>
    arrange(.year, .month)

  paths <- character(nrow(months))

  for (i in seq_len(nrow(months))) {
    yr  <- months$.year[i]
    mo  <- months$.month[i]
    chunk <- measurements |>
      filter(.year == yr, .month == mo) |>
      select(-.year, -.month)

    fp <- .raw_path(source, vessel_name, device_id,
                    year       = yr,
                    month      = mo,
                    data_start = min(chunk$datetime, na.rm = TRUE),
                    data_end   = max(chunk$datetime, na.rm = TRUE))
    arrow::write_parquet(chunk, fp)
    paths[i] <- fp
  }
  paths
}

.proc_path <- function(source, vessel_name, device_id, year, month) {
  dir <- file.path(.proc_dir(source, vessel_name), sprintf("%04d", year))
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  file.path(dir, sprintf("%s_%s_%04d%02d.parquet",
                         .safe(vessel_name), .safe(device_id), year, month))
}


# ============================================================================
# PAGINATED DOWNLOAD
# ============================================================================

#' Download all measurements for one device in a time window
#'
#' @param source              Character. "dbmatic", "efice", or "pefa"
#' @param journal_id          Character
#' @param device_id           Character
#' @param start_time          POSIXct (UTC)
#' @param end_time            POSIXct (UTC)
#' @param page_size           Integer. Records per API page (default 1000).
#'   Increase to 5000 to reduce API calls; reduce to 100 for testing.
#' @param sleep_between_pages Numeric. Seconds to wait between pages (default 0.1).
#'   Increase to 0.5-1.0 if the server rate-limits; set to 0 for max speed.
#' @return Tibble, sorted by datetime, duplicates removed
download_measurements <- function(source, journal_id, device_id,
                                   start_time, end_time,
                                   page_size           = 1000,
                                   sleep_between_pages = 0.1) {

  if (is.character(start_time))
    start_time <- as.POSIXct(start_time, tz = "UTC")
  if (is.character(end_time))
    end_time   <- as.POSIXct(end_time,   tz = "UTC")

  adp     <- .get_adapter(source)
  pages   <- list()
  offset  <- 0
  page_no <- 1

  repeat {
    cat(sprintf("\r  [%s] page %d (offset %d) ...", source, page_no, offset))

    page <- tryCatch(
      adp$get_meas(adp$base_url, adp$token,
                   journal_id, device_id,
                   start_time, end_time,
                   page_size, offset),
      error = function(e) {
        cat("\n")
        stop(e)
      }
    )

    if (nrow(page) == 0) break

    # Add provenance columns
    page <- page |>
      mutate(source     = source,
             journal_id = journal_id,
             device_id  = device_id)

    pages   <- c(pages, list(page))
    if (nrow(page) < page_size) break

    offset  <- offset + page_size
    page_no <- page_no + 1
    if (sleep_between_pages > 0) Sys.sleep(sleep_between_pages)
  }

  cat("\n")

  if (length(pages) == 0) return(tibble())

  bind_rows(pages) |>
    distinct(entry_id, .keep_all = TRUE) |>
    arrange(datetime)
}


# ============================================================================
# INCREMENTAL SYNC — one device
# ============================================================================

#' Sync one vessel/device combination
#'
#' @param source       Character. "dbmatic" or "efice"
#' @param journal_id   Character
#' @param device_id    Character
#' @param vessel_name  Character. Used as folder name
#' @param lookback_days Integer. Days to fetch on very first sync (default 30)
#' @param force_full   Logical.  Fetch from 2020-01-01 if TRUE
#' @return Tibble of newly downloaded records (invisibly)
#' @export
sync_device <- function(source, journal_id, device_id,
                         vessel_name         = "unknown",
                         lookback_days       = 30,
                         force_full          = FALSE,
                         page_size           = 1000,
                         sleep_between_pages = 0.1) {

  log_poseidat("Starting sync", source = source, vessel_id = journal_id)

  # Determine start of fetch window
  if (force_full) {
    start_time <- as.POSIXct("2020-01-01 00:00:00", tz = "UTC")
    log_poseidat("FULL sync — from 2020-01-01",
                 source = source, vessel_id = journal_id)
  } else {
    last <- get_last_sync_time(source, journal_id, device_id)
    if (is.null(last)) {
      start_time <- Sys.time() - (lookback_days * 86400)
      log_poseidat(sprintf("First sync — last %d days", lookback_days),
                   source = source, vessel_id = journal_id)
    } else {
      start_time <- last - 86400   # 1-day overlap for safety
      log_poseidat(sprintf("Incremental from %s",
                           format(last, "%Y-%m-%d")),
                   source = source, vessel_id = journal_id)
    }
  }
  end_time <- Sys.time()

  log_poseidat(sprintf("Range: %s → %s",
                       format(start_time, "%Y-%m-%d"),
                       format(end_time,   "%Y-%m-%d")),
               source = source, vessel_id = journal_id)

  # Download
  measurements <- tryCatch(
    download_measurements(source, journal_id, device_id,
                          start_time, end_time,
                          page_size           = page_size,
                          sleep_between_pages = sleep_between_pages),
    error = function(e) {
      log_poseidat(sprintf("Download failed: %s", e$message),
                   level = "ERROR", source = source, vessel_id = journal_id)
      tibble()
    }
  )

  if (nrow(measurements) == 0) {
    log_poseidat("No data returned", source = source, vessel_id = journal_id)
    return(invisible(tibble()))
  }

  log_poseidat(sprintf("Downloaded %d records", nrow(measurements)),
               source = source, vessel_id = journal_id)

  # Save parquet — split by actual data month → raw/<source>/<vessel>/YYYY/MM/
  # Using actual data dates (not requested window) so force_full syncs land
  # in the correct folders even when start_time is 2020-01-01.
  tryCatch({
    paths <- .save_by_month(measurements, source, vessel_name, device_id)
    log_poseidat(sprintf("Saved %d month file(s):", length(paths)),
                 source = source, vessel_id = journal_id)
    for (p in paths)
      log_poseidat(sprintf("  → %s", p), source = source, vessel_id = journal_id)
  }, error = function(e) {
    log_poseidat(sprintf("Save failed: %s", e$message),
                 level = "ERROR", source = source, vessel_id = journal_id)
  })

  # Update state
  max_dt <- max(measurements$datetime, na.rm = TRUE)
  update_last_sync_time(source, journal_id, device_id,
                         max_dt, nrow(measurements))
  log_poseidat(sprintf("Done — latest record: %s", format(max_dt, "%Y-%m-%d %H:%M:%S")),
               source = source, vessel_id = journal_id)

  invisible(measurements)
}


# ============================================================================
# SYNC ALL VESSELS
# ============================================================================

#' Sync all enabled vessels in vessel_config
#'
#' Iterates over all enabled rows, auto-discovers devices per vessel,
#' and calls sync_device() for each.
#'
#' @param vessel_config  Tibble. From Poseidat_config.R
#' @param sources        Character vector. Which sources to sync.
#'   Default NULL syncs all sources present in vessel_config.
#' @param lookback_days  Integer
#' @param force_full     Logical
#' @return Named list (one entry per journal_id__device_id)
#' @export
sync_all_vessels <- function(vessel_config,
                             sources             = NULL,
                             vessel_names        = NULL,
                             lookback_days       = 30,
                             force_full          = FALSE,
                             page_size           = 1000,
                             sleep_between_pages = 0.1) {
  cfg <- vessel_config |> filter(enabled)
  if (!is.null(sources))
    cfg <- cfg |> filter(source %in% sources)
  if (!is.null(vessel_names))                               # <-- add this block
    cfg <- cfg |> filter(vessel_name %in% vessel_names)
  if (nrow(cfg) == 0) {
    message("No enabled vessels match the requested sources/vessels.")
    return(invisible(list()))
  }

  log_poseidat(sprintf("=== Poseidat sync starting — %d vessel(s), source(s): %s ===",
                       nrow(cfg), paste(unique(cfg$source), collapse = ", ")))

  results <- list()

  for (i in seq_len(nrow(cfg))) {
    vessel <- cfg[i, ]

    log_poseidat(sprintf("--- [%d/%d] %s (%s) ---",
                         i, nrow(cfg), vessel$vessel_name, vessel$source),
                 source = vessel$source)

    # Auto-discover devices
    devices <- tryCatch(
      get_devices(vessel$source, vessel$journal_id),
      error = function(e) {
        log_poseidat(sprintf("Device discovery failed: %s", e$message),
                     level = "ERROR", source = vessel$source,
                     vessel_id = vessel$journal_id)
        tibble()
      }
    )

    if (nrow(devices) == 0) {
      log_poseidat("No devices found — skipping", level = "WARNING",
                   source = vessel$source, vessel_id = vessel$journal_id)
      next
    }

    for (j in seq_len(nrow(devices))) {
      dev <- devices[j, ]
      key <- paste(vessel$source, vessel$journal_id, dev$device_id, sep = "__")

      log_poseidat(sprintf("  Device %d/%d: %s",
                           j, nrow(devices), dev$device_name),
                   source = vessel$source, vessel_id = vessel$journal_id)

      results[[key]] <- tryCatch(
        sync_device(
          source              = vessel$source,
          journal_id          = vessel$journal_id,
          device_id           = dev$device_id,
          vessel_name         = vessel$vessel_name,
          lookback_days       = lookback_days,
          force_full          = force_full,
          page_size           = page_size,
          sleep_between_pages = sleep_between_pages
        ),
        error = function(e) {
          log_poseidat(sprintf("Sync error: %s", e$message),
                       level = "ERROR", source = vessel$source,
                       vessel_id = vessel$journal_id)
          tibble()
        }
      )

      Sys.sleep(1)
    }

    if (i < nrow(cfg)) Sys.sleep(3)
  }

  log_poseidat("=== Poseidat sync completed ===")
  invisible(results)
}


# ============================================================================
# DATA LOADING
# ============================================================================

#' Load all stored parquet data for a vessel/device combination
#'
#' Scans both raw (incremental) and processed (consolidated) folders.
#'
#' @param source      Character. "dbmatic" or "efice"
#' @param vessel_name Character
#' @param device_id   Character
#' @param start_date  Date or NULL
#' @param end_date    Date or NULL
#' @return Tibble, sorted by datetime, duplicates removed
#' @export
load_poseidat_data <- function(source, vessel_name, device_id,
                                start_date = NULL, end_date = NULL) {

  safe_dev <- .safe(device_id)
  pattern  <- glue(".*{safe_dev}.*\\.parquet$")

  raw_files  <- if (dir.exists(.raw_dir(source, vessel_name)))
    list.files(.raw_dir(source, vessel_name), pattern = pattern,
               recursive = TRUE, full.names = TRUE)
  else character(0)

  proc_files <- if (dir.exists(.proc_dir(source, vessel_name)))
    list.files(.proc_dir(source, vessel_name), pattern = pattern,
               recursive = TRUE, full.names = TRUE)
  else character(0)

  # Read processed first (prevents double-counting after consolidation)
  all_files <- c(proc_files, raw_files)

  if (length(all_files) == 0) {
    message(sprintf("No parquet files for [%s] %s / %s",
                    source, vessel_name, device_id))
    return(tibble())
  }

  message(sprintf("Loading %d file(s) for [%s] %s ...",
                  length(all_files), source, vessel_name))

  data <- map_dfr(all_files, arrow::read_parquet) |>
    distinct(entry_id, .keep_all = TRUE) |>
    arrange(datetime)

  if (!is.null(start_date))
    data <- data |> filter(as.Date(datetime) >= as.Date(start_date))
  if (!is.null(end_date))
    data <- data |> filter(as.Date(datetime) <= as.Date(end_date))

  message(sprintf("✓ Loaded %d records", nrow(data)))
  data
}


# ============================================================================
# WEEKLY CONSOLIDATION
# ============================================================================

#' Consolidate incremental raw parquet files into monthly processed files
#'
#' Files within the keep_daily_for_days window are left untouched.
#' Older raw files are merged into monthly processed parquets and removed.
#'
#' @param source              Character. "dbmatic" or "efice"
#' @param vessel_name         Character
#' @param device_id           Character
#' @param keep_daily_for_days Integer. Days of raw files to preserve (default 30)
#' @export
consolidate_data <- function(source, vessel_name, device_id,
                              keep_daily_for_days = 30) {

  log_poseidat(sprintf("Consolidation: [%s] %s / %s",
                       source, vessel_name, device_id))

  all_data <- load_poseidat_data(source, vessel_name, device_id)
  if (nrow(all_data) == 0) {
    log_poseidat("Nothing to consolidate")
    return(invisible(NULL))
  }

  cutoff <- Sys.Date() - keep_daily_for_days
  old    <- all_data |> filter(as.Date(datetime) < cutoff)

  if (nrow(old) == 0) {
    log_poseidat("No data old enough to consolidate")
    return(invisible(NULL))
  }

  old <- old |> mutate(.yr = year(datetime), .mo = month(datetime))

  for (yr in sort(unique(old$.yr))) {
    for (mo in sort(unique(old$.mo[old$.yr == yr]))) {
      month_data <- old |> filter(.yr == yr, .mo == mo) |> select(-.yr, -.mo)
      if (nrow(month_data) == 0) next

      fp <- .proc_path(source, vessel_name, device_id, yr, mo)
      arrow::write_parquet(month_data, fp)
      log_poseidat(sprintf("Consolidated %04d-%02d → %d records",
                           yr, mo, nrow(month_data)))
    }
  }

  # Remove consolidated raw files
  safe_dev  <- .safe(device_id)
  raw_files <- list.files(.raw_dir(source, vessel_name),
                           pattern   = glue(".*{safe_dev}.*\\.parquet$"),
                           recursive = TRUE, full.names = TRUE)

  for (fp in raw_files) {
    m <- regexec("_(\\d{8})_to_(\\d{8})\\.parquet$", basename(fp))
    if (m[[1]][1] != -1) {
      file_date <- as.Date(regmatches(basename(fp), m)[[1]][2], "%Y%m%d")
      if (!is.na(file_date) && file_date < cutoff) {
        file.remove(fp)
        log_poseidat(sprintf("Removed raw: %s", basename(fp)))
      }
    }
  }

  log_poseidat("Consolidation complete")
  invisible(NULL)
}


# ============================================================================
# SYNC STATE OVERVIEW
# ============================================================================

#' Print a summary of the current sync state for all tracked vessels/devices
#'
#' @export
print_sync_state <- function() {
  state <- get_sync_state()
  cat(sprintf("\nPoseidat sync state (last global sync: %s)\n",
              format(state$last_sync)))
  cat(strrep("-", 80), "\n")

  if (length(state$vessels) == 0) {
    cat("  No vessels synced yet.\n\n")
    return(invisible(NULL))
  }

  for (key in sort(names(state$vessels))) {
    v     <- state$vessels[[key]]
    parts <- strsplit(key, "__")[[1]]
    cat(sprintf(
      "  %-10s | %-36s | %-36s\n    last record : %s | records : %d\n\n",
      parts[1], parts[2], parts[3],
      format(v$last_sync_time),
      v$last_record_count
    ))
  }
  invisible(NULL)
}

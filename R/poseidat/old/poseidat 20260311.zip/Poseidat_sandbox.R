# ============================================================================
# Poseidat_sandbox.R
# Interactive exploration of the EFICE API and local parquet data.
#
# Run sections manually — each section is self-contained.
# Prerequisites: .Renviron must contain EFICE_API_URL, EFICE_TOKEN,
#               ONEDRIVE_POSEIDAT (see Poseidat_sync_functions.R header).
# ============================================================================

library(httr2)
library(dplyr)
library(purrr)
library(arrow)
library(lubridate)
library(ggplot2)

source(file.path(here::here(), "R", "poseidat", "Poseidat_sync_functions.R"))
source(file.path(here::here(), "R", "poseidat", "Poseidat_overview.R"))


# ============================================================================
# STEP 0 — Setup
# ============================================================================

setup_poseidat_sync()

# Load vessel config (journals + device labels)
vessel_config <- readRDS(file.path(.onedrive(), "config", "poseidat_vessels.rds"))


# ============================================================================
# STEP 1 — Explore the EFICE API
# ============================================================================

# 1a. List all journals (vessels) accessible with your token
efice_vessels <- get_vessels("efice")
print(efice_vessels)

# 1b. Inspect a single journal — returns vessel name, flag state, hull number
adp <- .get_adapter("efice")

resp <- request(paste0(adp$base_url, "/journals/",
                       efice_vessels$journal_id[1])) |>
  req_auth_bearer_token(adp$token) |>
  req_perform()
str(resp_body_json(resp), max.level = 2)

# 1c. List devices per vessel (sampled from recent entries)
efice_devices <- get_devices("efice", efice_vessels$journal_id[1])
print(efice_devices)

# 1d. Check which value_types each device produces
#     (samples 50 entries per device over a date range)
for (i in seq_len(nrow(efice_vessels))) {
  jid  <- efice_vessels$journal_id[i]
  name <- efice_vessels$vessel_name[i]
  cat(sprintf("\n=== %s (%s) ===\n", name, jid))

  devices <- get_devices("efice", jid)

  # Build label lookup for this vessel by journal_id
  cfg_row    <- which(vessel_config$journal_id == jid)
  dev_labels <- if (length(cfg_row) == 1) vessel_config$device_labels[[cfg_row]] else list()

  for (j in seq_len(nrow(devices))) {
    did   <- devices$device_id[j]
    label <- dev_labels[[did]]
    label <- if (is.null(label)) "(unlabelled)" else label

    fmt_dt <- function(t) format(t, "%Y-%m-%dT%H:%M:%SZ")

    # Sample 50 records for value_type detection + total count
    resp <- request(paste0(adp$base_url, "/journals/entries")) |>
      req_auth_bearer_token(adp$token) |>
      req_url_query(
        journalId = jid,
        deviceId  = did,
        startDate = "2020-01-01T00:00:00Z",
        endDate   = fmt_dt(Sys.time()),
        limit     = 50,
        skip      = 0
      ) |>
      req_error(is_error = \(r) FALSE) |>
      req_perform()

    data  <- resp_body_json(resp)
    types <- unique(sapply(data$items, \(x) x$value$type))
    total <- data$total %||% 0L

    parse_dt <- function(s) as.POSIXct(s, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")

    # API returns descending by default: skip=0 = most recent = last_dt
    last_dt <- tryCatch({
      r <- request(paste0(adp$base_url, "/journals/entries")) |>
        req_auth_bearer_token(adp$token) |>
        req_url_query(journalId = jid, deviceId = did,
                      startDate = "2020-01-01T00:00:00Z",
                      endDate   = fmt_dt(Sys.time()),
                      limit = 1L, skip = 0L) |>
        req_error(is_error = \(r) FALSE) |> req_timeout(15) |> req_perform()
      items <- resp_body_json(r)$items
      if (length(items) > 0) parse_dt(items[[1]]$entry_datetime) else NA
    }, error = function(e) NA)

    # skip=total-1 = oldest record = first_dt
    first_dt <- tryCatch({
      skip_to <- max(0L, as.integer(total) - 1L)
      r <- request(paste0(adp$base_url, "/journals/entries")) |>
        req_auth_bearer_token(adp$token) |>
        req_url_query(journalId = jid, deviceId = did,
                      startDate = "2020-01-01T00:00:00Z",
                      endDate   = fmt_dt(Sys.time()),
                      limit = 1L, skip = skip_to) |>
        req_error(is_error = \(r) FALSE) |> req_timeout(15) |> req_perform()
      items <- resp_body_json(r)$items
      if (length(items) > 0) parse_dt(items[[1]]$entry_datetime) else NA
    }, error = function(e) NA)

    # Sanity check — if first > last the API ordering assumption was wrong; swap
    if (!is.na(first_dt) && !is.na(last_dt) && first_dt > last_dt) {
      tmp <- first_dt; first_dt <- last_dt; last_dt <- tmp
    }

    cat(sprintf("  ...%s  %-20s  types: %-20s  total: %s  [%s -> %s]\n",
                substr(did, nchar(did) - 7, nchar(did)),
                label,
                paste(types, collapse = ", "),
                if (is.na(total) || is.null(total)) "?" else format(as.integer(total), big.mark = ","),
                if (is.na(first_dt) || !inherits(first_dt, "POSIXct")) "?" else format(first_dt, "%Y-%m-%d %H:%M"),
                if (is.na(last_dt)  || !inherits(last_dt,  "POSIXct")) "?" else format(last_dt,  "%Y-%m-%d %H:%M")))
    Sys.sleep(0.3)
  }
}

# 1e. Check monthly data availability for one device
check_monthly <- function(source, journal_id, device_id, year = 2026) {
  adp    <- .get_adapter(source)
  fmt_dt <- function(t) format(t, "%Y-%m-%dT%H:%M:%SZ")

  cat(sprintf("\nData availability: %s / ...%s / %d\n",
              source,
              substr(device_id, nchar(device_id) - 7, nchar(device_id)),
              year))
  cat(sprintf("%-10s %10s\n", "Month", "Records"))
  cat(strrep("-", 24), "\n")

  for (mo in 1:12) {
    start <- as.POSIXct(sprintf("%d-%02d-01", year, mo), tz = "UTC")
    end   <- as.POSIXct(sprintf("%d-%02d-01",
                                if (mo == 12) year + 1 else year,
                                if (mo == 12) 1L else mo + 1L), tz = "UTC")

    total <- tryCatch({
      resp <- request(paste0(adp$base_url, "/journals/entries")) |>
        req_auth_bearer_token(adp$token) |>
        req_url_query(journalId = journal_id, deviceId = device_id,
                      startDate = fmt_dt(start), endDate = fmt_dt(end),
                      limit = 1L, skip = 0L) |>
        req_error(is_error = \(r) FALSE) |>
        req_timeout(15) |>
        req_perform()
      resp_body_json(resp)$total %||% 0L
    }, error = function(e) NA_integer_)

    bar <- if (!is.na(total) && total > 0)
      strrep("|", min(20L, ceiling(total / 5000L))) else ""
    cat(sprintf("%-10s %10s  %s\n",
                month.abb[mo],
                if (is.na(total)) "error" else format(total, big.mark = ","),
                bar))
    Sys.sleep(0.2)
  }
}

# Example: check availability for Willem Jacob TRAWL_TENSION
check_monthly(
  source     = "efice",
  journal_id = get_journal_id(vessel_config, "Willem Jacob"),
  device_id  = get_device_by_label(vessel_config, "Willem Jacob", "TRAWL_TENSION"),
  year       = 2026
)


# ============================================================================
# STEP 2 — Download data for one device (in memory, no parquet save)
# ============================================================================

t_start <- Sys.time()

trawl <- download_measurements(
  source              = "efice",
  journal_id          = get_journal_id(vessel_config, "Willem Jacob"),
  device_id           = get_device_by_label(vessel_config, "Willem Jacob", "TRAWL_TENSION"),
  start_time          = as.POSIXct("2026-02-01", tz = "UTC"),
  end_time            = as.POSIXct("2026-03-04", tz = "UTC"),
  page_size           = 10000,
  sleep_between_pages = 0
)

cat(sprintf("Downloaded %d records in %s\n",
            nrow(trawl),
            format(round(Sys.time() - t_start, 1))))

glimpse(trawl)
summary(trawl[, c("traction_port", "traction_center", "traction_starboard",
                  "shooted_length_port", "shooted_length_starboard")])

# Quick trawl tension plot — towing periods only (traction_center > 500 kg)
trawl |>
  mutate(time_bin = floor(as.numeric(datetime) / 60)) |>
  group_by(time_bin) |>
  slice(1) |>
  ungroup() |>
  filter(traction_center > 500) |>
  tidyr::pivot_longer(
    cols      = c(traction_port, traction_center, traction_starboard),
    names_to  = "warp",
    values_to = "traction_kg"
  ) |>
  ggplot(aes(x = datetime, y = traction_kg, colour = warp)) +
  geom_line(alpha = 0.6, linewidth = 0.4) +
  scale_colour_brewer(palette = "Set1") +
  labs(title = "Willem Jacob — Trawl tension (towing only)",
       x = NULL, y = "Traction (kg)") +
  theme_bw()


# ============================================================================
# STEP 3 — Sync one device to parquet
# ============================================================================

t_start <- Sys.time()

sync_device(
  source              = "efice",
  journal_id          = get_journal_id(vessel_config, "Willem Jacob"),
  device_id           = get_device_by_label(vessel_config, "Willem Jacob", "POSITION"),
  vessel_name         = "Willem Jacob",
  lookback_days       = 30,
  page_size           = 5000,
  sleep_between_pages = 0
)

cat(sprintf("Sync completed in %s\n", format(round(Sys.time() - t_start, 1))))

# Verify files landed in the correct YYYY/MM folders
list.files(file.path(.onedrive(), "raw", "efice"),
           recursive = TRUE, pattern = "\\.parquet$")


# ============================================================================
# STEP 4 — Full sync: all vessels, all devices
# ============================================================================

t_start <- Sys.time()

sync_all_vessels(
  vessel_config       = vessel_config,
  sources             = "efice",
  lookback_days       = 30,       # ignored when force_full = TRUE
  force_full          = FALSE,    # set TRUE only for initial backfill
  page_size           = 5000,
  sleep_between_pages = 0
)

cat(sprintf("Full sync completed in %s\n", format(round(Sys.time() - t_start, 1))))

# Check sync state — last sync time and record counts per vessel/device
print_sync_state()


# ============================================================================
# STEP 5 — Verify stored data
# ============================================================================

# What files exist and how large?
poseidat_files() |> print(n = 50)

# What value_types are stored per vessel / device?
poseidat_value_types()

# Daily record counts — useful for spotting gaps or unexpected spikes
poseidat_daily(source = "efice") |> print(n = 60)

# Statistical summary (min/mean/max) per value_type
poseidat_summary(source = "efice")


# ============================================================================
# STEP 5b — Compare API availability vs local parquet
#
# Shows first/last datetime from the API (what is available to download)
# alongside first/last from local parquet (what has already been synced).
# Useful for spotting gaps between what the API holds and what is stored.
# ============================================================================

# --- Local parquet summary with readable labels ---
cfg_labels <- vessel_config |>
  dplyr::select(journal_id, vessel_name, device_labels) |>
  tidyr::unnest_longer(device_labels,
                       indices_to = "device_id",
                       values_to  = "label") |>
  dplyr::select(vessel_name, device_id, label)

parquet_range <- poseidat_value_types(source = "efice") |>
  left_join(cfg_labels, by = c("vessel_name", "device_id")) |>
  mutate(label = coalesce(label,
                          substr(device_id, nchar(device_id) - 7, nchar(device_id)))) |>
  dplyr::select(vessel_name, label, value_type,
                parquet_n     = n_records,
                parquet_first = first_obs,
                parquet_last  = last_obs)

# --- API summary (first/last per device) ---
adp      <- .get_adapter("efice")
fmt_dt   <- function(t) format(t, "%Y-%m-%dT%H:%M:%SZ")
parse_dt <- function(s) as.POSIXct(s, format = "%Y-%m-%dT%H:%M:%SZ", tz = "UTC")

api_range <- map_dfr(seq_len(nrow(efice_vessels)), function(i) {
  jid        <- efice_vessels$journal_id[i]
  name       <- efice_vessels$vessel_name[i]
  cfg_row    <- which(vessel_config$journal_id == jid)
  dev_labels <- if (length(cfg_row) == 1) vessel_config$device_labels[[cfg_row]] else list()
  devices    <- get_devices("efice", jid)

  map_dfr(seq_len(nrow(devices)), function(j) {
    did   <- devices$device_id[j]
    label <- dev_labels[[did]]
    label <- if (is.null(label)) substr(did, nchar(did) - 7, nchar(did)) else label

    # Total count + value_types from a small sample
    resp  <- request(paste0(adp$base_url, "/journals/entries")) |>
      req_auth_bearer_token(adp$token) |>
      req_url_query(journalId = jid, deviceId = did,
                    startDate = "2020-01-01T00:00:00Z",
                    endDate   = fmt_dt(Sys.time()),
                    limit = 10L, skip = 0L) |>
      req_error(is_error = \(r) FALSE) |> req_timeout(15) |> req_perform()
    data  <- resp_body_json(resp)
    total <- data$total %||% 0L
    types <- unique(sapply(data$items, \(x) x$value$type))

    # Most recent (skip=0, API returns descending by default)
    api_last <- tryCatch({
      r <- request(paste0(adp$base_url, "/journals/entries")) |>
        req_auth_bearer_token(adp$token) |>
        req_url_query(journalId = jid, deviceId = did,
                      startDate = "2020-01-01T00:00:00Z",
                      endDate   = fmt_dt(Sys.time()),
                      limit = 1L, skip = 0L) |>
        req_error(is_error = \(r) FALSE) |> req_timeout(15) |> req_perform()
      items <- resp_body_json(r)$items
      if (length(items) > 0) parse_dt(items[[1]]$entry_datetime) else NA
    }, error = function(e) NA)

    # Oldest (skip = total - 1)
    api_first <- tryCatch({
      r <- request(paste0(adp$base_url, "/journals/entries")) |>
        req_auth_bearer_token(adp$token) |>
        req_url_query(journalId = jid, deviceId = did,
                      startDate = "2020-01-01T00:00:00Z",
                      endDate   = fmt_dt(Sys.time()),
                      limit = 1L, skip = max(0L, as.integer(total) - 1L)) |>
        req_error(is_error = \(r) FALSE) |> req_timeout(15) |> req_perform()
      items <- resp_body_json(r)$items
      if (length(items) > 0) parse_dt(items[[1]]$entry_datetime) else NA
    }, error = function(e) NA)

    # Guarantee chronological order
    if (!is.na(api_first) && !is.na(api_last) && api_first > api_last) {
      tmp <- api_first; api_first <- api_last; api_last <- tmp
    }

    tibble(vessel_name = name, label = label,
           value_type  = paste(types, collapse = ", "),
           api_n       = as.integer(total),
           api_first   = api_first,
           api_last    = api_last)
  })
})

# --- Parquet summary aggregated to device level (sum across value_types) ---
parquet_by_device <- parquet_range |>
  group_by(vessel_name, label) |>
  summarise(
    parquet_types = paste(sort(unique(value_type)), collapse = ", "),
    parquet_n     = sum(parquet_n, na.rm = TRUE),
    parquet_first = min(parquet_first, na.rm = TRUE),
    parquet_last  = max(parquet_last,  na.rm = TRUE),
    .groups = "drop"
  )

# --- Side-by-side comparison joined at device level ---
comparison <- full_join(
  api_range,
  parquet_by_device,
  by = c("vessel_name", "label")
) |>
  mutate(
    n_missing   = api_n - coalesce(parquet_n, 0L),
    behind_days = round(as.numeric(difftime(
      api_last, coalesce(parquet_last, api_first), units = "days")), 1)
  ) |>
  dplyr::select(vessel_name, label, value_type, parquet_types,
                api_n, api_first, api_last,
                parquet_n, parquet_first, parquet_last,
                n_missing, behind_days) |>
  arrange(vessel_name, label)

cat("\n=== API vs Parquet comparison (device level) ===\n")
comparison |>
  mutate(across(c(api_first, api_last, parquet_first, parquet_last),
                \(x) format(x, "%Y-%m-%d %H:%M"))) |>
  print(n = 50, width = 160)


# ============================================================================
# STEP 6 — Thin to 1-minute intervals and map
# ============================================================================

# Thin all raw data to 1-minute averages and save to processed/thinned/
poseidat_thin(save = TRUE)

# Interactive vessel track map — all vessels, 5-minute position thinning
poseidat_map()

# Filtered map — specific vessels and date range
pos <- poseidat_positions(
  vessel_name  = c("Lub Senior", "Willem Jacob"),
  start_date   = as.Date("2026-02-20"),
  end_date     = as.Date("2026-03-04"),
  thin_minutes = 5
)
poseidat_map(pos)

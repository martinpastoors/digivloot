# Poseidat R Functions Overview

Architecture and function reference for the unified Poseidat data sync pipeline.
Three API sources — **DBMatic** (test), **EFICE** (production), **PEFA** (production) — all delivering the same Poseidat vessel journal sensor data for different vessel/period combinations.

---

## File Structure

```
R/Poseidat/
├── Poseidat_config.R          # Vessel configuration & OneDrive path setup
├── Poseidat_sync_functions.R  # All sync, API, storage and utility functions
├── Poseidat_sync_daily.R      # Scheduled daily runner
└── Poseidat_sandbox.R         # Interactive exploration & API probing
```

---

## Architecture Overview

```mermaid
graph TD
    CFG["📄 Poseidat_config.R<br/>vessel_config tibble<br/>OneDrive path"]
    DAILY["📄 Poseidat_sync_daily.R<br/>Scheduled runner"]
    SANDBOX["📄 Poseidat_sandbox.R<br/>Interactive exploration"]
    CORE["📄 Poseidat_sync_functions.R"]

    CFG -->|"vessel_config.rds"| DAILY
    CFG -->|"vessel_config.rds"| SANDBOX
    DAILY -->|source| CORE
    SANDBOX -->|source| CORE

    subgraph CORE["Poseidat_sync_functions.R"]
        direction TB
        PUB["Public API<br/>get_vessels · get_devices<br/>sync_device · sync_all_vessels<br/>download_measurements<br/>load_poseidat_data · consolidate_data<br/>print_sync_state"]
        ADP["Adapters<br/>.dbmatic_* · .efice_* · .pefa_*"]
        INFRA["Infrastructure<br/>setup · logging · state · storage paths"]
        HTTP[".http_get()"]

        PUB --> ADP
        ADP --> HTTP
        PUB --> INFRA
    end

    HTTP -->|HTTPS| DBMATIC["🌐 DBMatic API<br/>(test data)"]
    HTTP -->|HTTPS| EFICE["🌐 EFICE API<br/>(production)"]
    HTTP -->|HTTPS| PEFA["🌐 PEFA API<br/>(production)"]

    INFRA -->|parquet| OD["💾 OneDrive / Poseidat<br/>raw · processed · config · logs"]
```

---

## Poseidat_sync_functions.R

### Setup

```mermaid
graph LR
    setup_poseidat_sync["setup_poseidat_sync()<br/><i>Resolves OneDrive path, creates<br/>directory skeleton, initialises<br/>state file, validates credentials</i>"]
    onedrive[".onedrive()<br/><i>Internal getter for<br/>OneDrive base path</i>"]
    setup_poseidat_sync --> onedrive
```

| Function | Type | Purpose |
|---|---|---|
| `setup_poseidat_sync(onedrive_base)` | public | Configure credentials, create folder structure, initialise state |
| `.onedrive()` | internal | Return OneDrive base path from options |

---

### Logging

```mermaid
graph LR
    log_poseidat["log_poseidat(msg, level, source, vessel_id)<br/><i>Writes timestamped entry to<br/>monthly .log file + console</i>"]
    logfile["💾 logs/poseidat_sync_YYYYMM.log"]
    log_poseidat --> logfile
```

| Function | Type | Purpose |
|---|---|---|
| `log_poseidat(msg, level, source, vessel_id)` | internal | Write INFO / WARNING / ERROR to monthly log file and console |

---

### State Management

```mermaid
graph LR
    get_sync_state["get_sync_state()"]
    save_sync_state["save_sync_state(state)"]
    get_last["get_last_sync_time(source, journal_id, device_id)"]
    update_last["update_last_sync_time(source, journal_id, device_id,<br/>sync_time, record_count)"]
    statefile["💾 config/sync_state.rds<br/><i>keyed: source__journal_id__device_id</i>"]

    get_sync_state <--> statefile
    save_sync_state --> statefile
    get_last --> get_sync_state
    update_last --> save_sync_state
```

| Function | Type | Purpose |
|---|---|---|
| `get_sync_state()` | internal | Load full state list from RDS |
| `save_sync_state(state)` | internal | Persist state list to RDS |
| `get_last_sync_time(source, journal_id, device_id)` | internal | Return last successful sync datetime for one vessel/device, or NULL |
| `update_last_sync_time(...)` | internal | Record latest datetime and record count after a successful download |

---

### HTTP Layer

```mermaid
graph LR
    http[".http_get(base_url, api_token, endpoint, params)<br/><i>Authenticated GET · 3 retries · error check<br/>Returns parsed JSON list</i>"]
    api["🌐 API endpoint"]
    http -->|"req_auth_bearer_token<br/>req_retry(max_tries=3)"| api
```

| Function | Type | Purpose |
|---|---|---|
| `.http_get(base_url, api_token, endpoint, params)` | internal | Single authenticated GET with retry; returns parsed JSON |

---

### API Adapters

All three adapters expose an identical three-function interface. The core sync logic calls only this interface and never references a specific source directly.

```mermaid
graph TD
    dispatcher[".get_adapter(source)<br/><i>Returns list of base_url, token,<br/>and the three adapter functions</i>"]

    dispatcher -->|source = dbmatic| dbm["DBMatic adapter<br/>.dbmatic_get_vessels()<br/>.dbmatic_get_devices()<br/>.dbmatic_get_measurements()"]
    dispatcher -->|source = efice| efi["EFICE adapter<br/>.efice_get_vessels()<br/>.efice_get_devices()<br/>.efice_get_measurements()"]
    dispatcher -->|source = pefa| pfa["PEFA adapter<br/>.pefa_get_vessels()<br/>.pefa_get_devices()<br/>.pefa_get_measurements()"]

    dbm -->|delegates to| http[".http_get()"]
    efi -->|delegates to dbmatic_*| dbm
    pfa -->|delegates to dbmatic_*| dbm
```

| Function | Source | Purpose |
|---|---|---|
| `.dbmatic_get_vessels(base_url, token)` | dbmatic | Fetch journal list → tibble |
| `.dbmatic_get_devices(base_url, token, journal_id)` | dbmatic | Fetch equipment inventory → tibble |
| `.dbmatic_get_measurements(base_url, token, journal_id, device_id, start, end, page_size, offset)` | dbmatic | Fetch one page of measurements → tibble |
| `.efice_get_vessels/devices/measurements(...)` | efice | Delegate to DBMatic adapter; update if EFICE endpoints differ |
| `.pefa_get_vessels/devices/measurements(...)` | pefa | Delegate to DBMatic adapter; update if PEFA endpoints differ |
| `.get_adapter(source)` | — | Dispatcher: return credentials + adapter functions for a given source |

---

### Public Discovery Functions

```mermaid
graph LR
    get_vessels["get_vessels(source)<br/><i>Returns tibble:<br/>journal_id, vessel_name, cfr, flag_state</i>"]
    get_devices["get_devices(source, journal_id)<br/><i>Returns tibble:<br/>device_id, device_name, device_type</i>"]
    adapter[".get_adapter()"]
    get_vessels --> adapter
    get_devices --> adapter
```

| Function | Type | Purpose |
|---|---|---|
| `get_vessels(source)` | **public** | List all vessels accessible with the source token |
| `get_devices(source, journal_id)` | **public** | List all devices on a vessel |

---

### Storage Path Helpers

```mermaid
graph LR
    safe[".safe(x)<br/><i>Sanitise string for use<br/>in file/folder names</i>"]
    raw_dir[".raw_dir(source, vessel_name)"]
    proc_dir[".proc_dir(source, vessel_name)"]
    raw_path[".raw_path(source, vessel_name, device_id,<br/>start_time, end_time)<br/><i>Creates YYYY/MM subfolder</i>"]
    proc_path[".proc_path(source, vessel_name, device_id,<br/>year, month)<br/><i>Creates YYYY subfolder</i>"]

    raw_dir --> raw_path
    proc_dir --> proc_path
    safe --> raw_path
    safe --> proc_path
```

Resulting paths:

```
raw/<source>/<vessel>/YYYY/MM/<vessel>_<device>_YYYYMMDD_to_YYYYMMDD.parquet
processed/<source>/<vessel>/YYYY/<vessel>_<device>_YYYYMM.parquet
```

---

### Core Sync Functions

```mermaid
flowchart TD
    sync_all["sync_all_vessels(vessel_config, sources,<br/>lookback_days, force_full)<br/><i>Iterates enabled vessels,<br/>auto-discovers devices per vessel</i>"]
    sync_dev["sync_device(source, journal_id, device_id,<br/>vessel_name, lookback_days, force_full)<br/><i>Determines fetch window,<br/>downloads, saves, updates state</i>"]
    dl["download_measurements(source, journal_id, device_id,<br/>start_time, end_time, page_size)<br/><i>Paginated download loop<br/>Returns deduplicated tibble</i>"]
    get_dev["get_devices()"]
    get_last["get_last_sync_time()"]
    update["update_last_sync_time()"]
    raw_path[".raw_path()"]
    parquet["💾 raw/.../YYYY/MM/*.parquet"]
    adapter[".get_adapter()"]

    sync_all -->|for each vessel| get_dev
    sync_all -->|for each device| sync_dev
    sync_dev --> get_last
    sync_dev --> dl
    dl --> adapter
    adapter -->|paginated GET| http[".http_get()"]
    sync_dev --> raw_path
    sync_dev -->|arrow::write_parquet| parquet
    sync_dev --> update
```

| Function | Type | Purpose |
|---|---|---|
| `download_measurements(source, journal_id, device_id, start_time, end_time, page_size)` | **public** | Paginated download of all records in time window; returns deduplicated tibble |
| `sync_device(source, journal_id, device_id, vessel_name, lookback_days, force_full)` | **public** | Incremental sync for one vessel/device: determines window, downloads, saves parquet, updates state |
| `sync_all_vessels(vessel_config, sources, lookback_days, force_full)` | **public** | Sync all enabled vessels; auto-discovers devices; returns named result list |

---

### Data Loading & Consolidation

```mermaid
flowchart LR
    load["load_poseidat_data(source, vessel_name, device_id,<br/>start_date, end_date)<br/><i>Scans both raw/ and processed/,<br/>deduplicates on entry_id</i>"]
    consolidate["consolidate_data(source, vessel_name, device_id,<br/>keep_daily_for_days)<br/><i>Merges old raw files into<br/>monthly processed parquets,<br/>removes consolidated raws</i>"]
    raw["💾 raw/<source>/<vessel>/YYYY/MM/*.parquet"]
    processed["💾 processed/<source>/<vessel>/YYYY/*.parquet"]
    print_state["print_sync_state()<br/><i>Console summary of all<br/>tracked vessel/device states</i>"]
    state["💾 config/sync_state.rds"]

    raw --> load
    processed --> load
    load -->|old records| consolidate
    consolidate --> processed
    consolidate -->|removes| raw
    state --> print_state
```

| Function | Type | Purpose |
|---|---|---|
| `load_poseidat_data(source, vessel_name, device_id, start_date, end_date)` | **public** | Load all parquet files for a vessel/device; deduplicates; optional date filter |
| `consolidate_data(source, vessel_name, device_id, keep_daily_for_days)` | **public** | Merge raw incremental files older than N days into monthly processed files; remove originals |
| `print_sync_state()` | **public** | Print console overview of last sync time and record counts for all tracked combinations |

---

## Poseidat_config.R

```mermaid
graph LR
    cfg["Poseidat_config.R<br/><i>Edit vessel_config tibble here<br/>to add or disable vessels</i>"]
    rds["💾 config/poseidat_vessels.rds"]
    daily["Poseidat_sync_daily.R"]
    sandbox["Poseidat_sandbox.R"]

    cfg -->|"saveRDS()"| rds
    rds -->|"readRDS()"| daily
    rds -->|"readRDS()"| sandbox
```

**`vessel_config` columns:**

| Column | Description |
|---|---|
| `source` | `"dbmatic"` · `"efice"` · `"pefa"` |
| `journal_id` | Vessel UUID in the respective API |
| `vessel_name` | Used as OneDrive folder name (no spaces) |
| `cfr` | Community Fleet Register number (cross-reference) |
| `enabled` | `FALSE` to skip without removing the row |

---

## Poseidat_sync_daily.R

```mermaid
flowchart TD
    start(["⏰ Scheduled trigger<br/>(Task Scheduler / cron)"])
    setup["setup_poseidat_sync()"]
    load_cfg["readRDS(poseidat_vessels.rds)"]
    sync["sync_all_vessels(sources = c('efice','pefa'))"]
    monday{"wday == Monday?"}
    consolidate["consolidate_data()<br/><i>for each enabled vessel/device</i>"]
    state["print_sync_state()"]
    done(["✓ Done"])

    start --> setup --> load_cfg --> sync --> monday
    monday -->|Yes| consolidate --> state --> done
    monday -->|No| state --> done
```

---

## Poseidat_sandbox.R

Interactive exploration script — run sections manually in sequence.

```mermaid
graph TD
    A["Section A — DBMatic<br/>Explore test vessels & devices<br/>Check monthly data availability<br/>Manual sync & load"]
    B["Section B — EFICE API probing<br/>efice_probe() on common endpoints<br/>Discover journals, equipment,<br/>measurement structure"]
    C["Section C — EFICE production sync<br/>get_vessels · get_devices<br/>check_monthly · download · sync<br/>load & inspect stored data"]
    E["Section E — PEFA API probing<br/>pefa_probe() on common endpoints<br/>Verify same structure as DBMatic/EFICE<br/>Update adapter if needed"]
    F["Section F — All sources<br/>print_sync_state()<br/>Cross-source data inspection<br/>Manual consolidation"]

    A --> B --> C --> E --> F
```

---

## OneDrive Folder Layout

```
OneDrive/Poseidat/
├── config/
│   ├── poseidat_vessels.rds     ← vessel config (written by Poseidat_config.R)
│   └── sync_state.rds           ← incremental sync state (per source/vessel/device)
├── logs/
│   └── poseidat_sync_YYYYMM.log
├── raw/
│   ├── dbmatic/
│   │   └── <vessel>/YYYY/MM/<vessel>_<device>_YYYYMMDD_to_YYYYMMDD.parquet
│   ├── efice/
│   │   └── <vessel>/YYYY/MM/<vessel>_<device>_YYYYMMDD_to_YYYYMMDD.parquet
│   └── pefa/
│       └── <vessel>/YYYY/MM/<vessel>_<device>_YYYYMMDD_to_YYYYMMDD.parquet
└── processed/
    ├── dbmatic/
    │   └── <vessel>/YYYY/<vessel>_<device>_YYYYMM.parquet
    ├── efice/
    │   └── <vessel>/YYYY/<vessel>_<device>_YYYYMM.parquet
    └── pefa/
        └── <vessel>/YYYY/<vessel>_<device>_YYYYMM.parquet
```

---

## .Renviron Credentials

```sh
DBMATIC_API_URL   = https://api.dbmatic.eu/api/v1
DBMATIC_TOKEN     = your-dbmatic-bearer-token
EFICE_API_URL     = https://...
EFICE_TOKEN       = your-efice-bearer-token
PEFA_API_URL      = https://...
PEFA_TOKEN        = your-pefa-bearer-token
ONEDRIVE_POSEIDAT = C:/Users/<you>/OneDrive/Poseidat
```

Edit with `usethis::edit_r_environ()`.

---

## Required R Packages

| Package | Role |
|---|---|
| `httr2` | API requests |
| `arrow` | Parquet read/write |
| `dplyr` | Data manipulation |
| `purrr` | Functional iteration |
| `glue` | String interpolation |
| `lubridate` | Date/time handling |
| `here` | Project-relative paths |
